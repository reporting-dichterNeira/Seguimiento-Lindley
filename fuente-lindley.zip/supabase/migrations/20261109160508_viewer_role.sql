alter table public.lindley_profiles drop constraint if exists lindley_profiles_role_check;
alter table public.lindley_profiles add constraint lindley_profiles_role_check check (role in ('admin','auditor','viewer'));
