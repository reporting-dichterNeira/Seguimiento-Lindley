begin;
alter table public.lindley_datasets drop constraint if exists lindley_datasets_kind_check;
alter table public.lindley_datasets add constraint lindley_datasets_kind_check
 check(kind in ('universe','export','forecast','routes','mappings','calendar'));

-- Compare and activate under the same lock. Concurrent administrator saves
-- must not silently replace another administrator's calendar.
create or replace function public.lindley_activate_calendar(
 p_period text,p_path text,p_count integer,p_user uuid,p_version text
) returns boolean language plpgsql security invoker set search_path=public as $$
declare current_path text;
begin
 perform pg_advisory_xact_lock(hashtextextended('lindley-calendar:'||p_period,0));
 select path into current_path from public.lindley_datasets where period=p_period and kind='calendar';
 if coalesce(current_path,'')<>coalesce(p_version,'') then return false; end if;
 perform public.lindley_activate_dataset(p_period,'calendar',p_path,p_count,'Calendario de días de campo',p_user);
 return true;
end; $$;
revoke all on function public.lindley_activate_calendar(text,text,integer,uuid,text) from public,anon,authenticated;
grant execute on function public.lindley_activate_calendar(text,text,integer,uuid,text) to service_role;
commit;
