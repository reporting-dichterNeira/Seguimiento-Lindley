// Lindley shared MT: equal targets and individual approved production.
const normalize = value => String(value ?? '').trim().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
const isTitan = program => normalize(program).startsWith('TIT');
function wavePeriod(wave) {
 const text=normalize(wave), year=text.match(/20\d{2}/)?.[0];
 const months=['ENE','FEB','MAR','ABR','MAY','JUN','JUL','AGO','SEP','OCT','NOV','DIC'];
 const month=months.findIndex(m=>text.startsWith(m));
 return year && month>=0 ? `${year}-${String(month+1).padStart(2,'0')}` : '';
}
const newMetric = (key,name=key) => ({key,name,quota:0,forecast:0,tit:0,sup:0,approved:0,visited:0,review:0,closedTemporary:0,titUnvisited:0,fullForecast:0,incidences:0,cancelled:0,titanQuota:0,titanApproved:0,titanIncidences:0,titanCancelled:0,titanUnvisited:0,titanForecast:null,unclassified:0,unassigned:0});
/** @param {any} input */
function calculateStudy({universe=[],visits=[],forecast=[],routes=[],mappings=[],accounts=[],period='2026-09',cutoff='9999-12-31',viewer=null}) {
 const admin = !viewer;
 const integratedPlan=universe.length>0&&universe.every(p=>p.mt&&Number.isInteger(p.fieldDay));
 const mtUsers=new Map();
 for(const r of mappings.filter(r=>r.active!==false&&!r.removed)){const mt=normalize(r.mt),users=mtUsers.get(mt)||[];if(!users.includes(r.user))users.push(r.user);mtUsers.set(mt,users)}
 const ownersFor=p=>integratedPlan?(mtUsers.get(normalize(p?.mt))||['mt:'+normalize(p?.mt)]):[assignment.get(routeKey(p?.route))?.user||'Sin asignar'];
 const ownerFor=p=>integratedPlan?ownersFor(p)[0]:assignment.get(routeKey(p?.route))?.user;
 const fieldDates=[...new Set(visits.filter(v=>wavePeriod(v.wave)===period).map(v=>v.date))].sort();
 const dayForDate=new Map(fieldDates.map((date,i)=>[date,i+1]));
 const currentFieldDay=fieldDates.filter(date=>date<=cutoff).length;
 const planDays=integratedPlan?universe.reduce((max,p)=>Math.max(max,p.fieldDay),0):0;
 if(integratedPlan){
  const planned=new Map();const months=['ENE','FEB','MAR','ABR','MAY','JUN','JUL','AGO','SEP','OCT','NOV','DIC'];
  for(const p of universe){if(normalize(p.selection)!=='T')continue;for(const user of ownersFor(p)){const weight=1/ownersFor(p).length,key=JSON.stringify([user,p.cda,p.fieldDay]);let f=planned.get(key);if(!f){f={user,cda:p.cda,fieldDay:p.fieldDay,mt:p.mt,date:fieldDates[p.fieldDay-1]||'9999-12-31',wave:months[Number(period.slice(5))-1]+' '+period.slice(0,4),forecast:0,titanForecast:0};planned.set(key,f)}f.forecast+=weight;if(isTitan(p.program))f.titanForecast+=weight;}}
  forecast=[...planned.values()];
 }

 const um=new Map(universe.map(r=>[r.code,r]));
 const routeKey=value=>normalize(value);
 const routeUsers=new Map();
 for(const v of visits){
  if(wavePeriod(v.wave)!==period || v.date>cutoff || !v.route || !v.user)continue;
  const key=routeKey(v.route), users=routeUsers.get(key)||new Set();users.add(v.user);routeUsers.set(key,users);
 }
 const assignment=new Map();
 for(const [route,users] of routeUsers)if(users.size===1)assignment.set(route,{route,user:[...users][0],inferred:true});
 for(const r of routes)assignment.set(routeKey(r.route),r);
 const effectiveRoutes=[...assignment.values()];
 const ambiguousRoutes=[...routeUsers].filter(([route,users])=>users.size>1&&!assignment.has(route)).map(([route,users])=>({route,auditors:[...users].sort()}));
 const unassignedRoutes=integratedPlan?[]:[...new Set(universe.filter(p=>!assignment.has(routeKey(p.route))).map(p=>p.route))].sort();
 const names=new Map(routes.filter(r=>r.name).map(r=>[r.user,r.name]));
 for(const r of accounts)if(r.name)names.set(r.auditor,r.name);
 if(integratedPlan)for(const p of universe){for(const user of ownersFor(p))if(!names.has(user))names.set(user,p.mt+(user.startsWith('mt:')?' · Sin homologar':''));}
 const routeCdas=new Map();
 for(const v of visits) if(v.cda && v.route && wavePeriod(v.wave)===period) {
  const set=routeCdas.get(routeKey(v.route))||new Set();set.add(v.cda);routeCdas.set(routeKey(v.route),set);
 }
 const cdaFor=p=>integratedPlan?(p?.cda||'Sin CDA'):assignment.get(routeKey(p?.route))?.cda || (routeCdas.get(routeKey(p?.route))?.size===1 ? [...routeCdas.get(routeKey(p.route))][0] : p?.cda || 'Sin CDA');
 const byCda=new Map(), byAuditor=new Map(), total=newMetric('TOTAL','Total');
 const get=(map,key)=>{if(!map.has(key))map.set(key,newMetric(key,map===byAuditor?names.get(key)||key:key));return map.get(key)};
 const groups=(p,user)=>[total,get(byCda,cdaFor(p)),get(byAuditor,user||'Sin asignar')];
 const visiblePoint=p=>admin || ownersFor(p).includes(viewer) || (approved.get(p.code)||latest.get(p.code))?.user===viewer;
 const latest=new Map(), approved=new Map(), userCdas=new Map(), forecastCdas=new Map();
 for(const v of visits) {
  if(wavePeriod(v.wave)!==period || !v.code || v.date>cutoff)continue;
  const old=latest.get(v.code);
  if(!old || `${v.date}|${v.updated}|${v.id}`>`${old.date}|${old.updated}|${old.id}`)latest.set(v.code,v);
  if(normalize(v.state)==='APROBADA') {
   const oldApproved=approved.get(v.code);
   if(!oldApproved || `${v.date}|${v.updated}|${v.id}`>`${oldApproved.date}|${oldApproved.updated}|${oldApproved.id}`)approved.set(v.code,v);
  }
  const p=um.get(v.code)||v;
  const cds=userCdas.get(v.user)||new Set();cds.add(cdaFor(p));userCdas.set(v.user,cds);
 }
 const points=[], daily=new Map(), plannedDaily=new Map(), dailyStates=new Map(), unmatched=[], assignedUsers=new Set();
 for(const p of universe) {
  if(!visiblePoint(p))continue;
  const owners=ownersFor(p),owner=admin?owners[0]:(owners.includes(viewer)?viewer:owners[0]);
  const weight=1/owners.length;
  const planGroups=()=>admin?[total,get(byCda,cdaFor(p)),...owners.map(u=>get(byAuditor,u))]:groups(p,owner);
  const amount=m=>admin&&(m===total||m===byCda.get(cdaFor(p)))?1:weight;
  for(const u of owners)assignedUsers.add(u);
  if(owner!=='Sin asignar')assignedUsers.add(owner);
  if((admin||owner===viewer)&&normalize(p.selection)==='T')for(const metric of planGroups()) {
   metric.quota+=amount(metric);if(isTitan(p.program))metric.titanQuota+=amount(metric);
   if(owner==='Sin asignar')metric.unassigned++;
  }
  const resolved=approved.get(p.code)||latest.get(p.code);
  const v=admin||resolved?.user===viewer?resolved:undefined;
  if((admin||owner===viewer)&&normalize(p.selection)==='T'&&!resolved)for(const metric of planGroups())metric.titUnvisited+=amount(metric);
  if((admin||owners.includes(viewer))&&normalize(p.selection)==='T' && isTitan(p.program) && !resolved)for(const metric of planGroups())metric.titanUnvisited+=amount(metric);
  if(normalize(p.selection)==='T' || v)points.push({...p,cda:cdaFor(p),user:v?.user||owner,assignedUser:owner,assignedUsers:owners,quotaShare:weight,mt:p.mt||'',fieldDay:p.fieldDay??null,actualFieldDay:v?dayForDate.get(v.date):null,assignmentSource:integratedPlan?'MT del plan':assignment.get(routeKey(p.route))?.inferred?'Export por ruta':owner==='Sin asignar'?'Pendiente':'Asignación confirmada',state:v?.state||'Sin visitar',date:v?.date||'',titan:isTitan(p.program)});
 }
 for(const [pointCode,last] of latest) {
  const v=approved.get(pointCode)||last;
  if(!admin && v.user!==viewer)continue;
  const p=um.get(pointCode), gs=groups(p||v,v.user);
  if(!p)unmatched.push({code:v.code,state:v.state,user:v.user});
  const status=normalize(v.state),incidence=normalize(v.incidence);
  const day=dailyStates.get(v.date)||{review:0,incidences:0,cancelled:0};
  if(status==='INCIDENCIA')day.incidences++;else if(status==='CANCELADA')day.cancelled++;else if(status!=='APROBADA')day.review++;
  dailyStates.set(v.date,day);
  for(const metric of gs) {
   metric.visited++;
   if(!['APROBADA','INCIDENCIA','CANCELADA'].includes(status))metric.review++;
   if(status==='INCIDENCIA'&&incidence==='CERRADO TEMPORAL')metric.closedTemporary++;
   if(!p)metric.unclassified++;
   if(normalize(v.state)==='APROBADA') {metric.approved++; if(p && normalize(p.selection)==='T')metric.tit++;else if(p)metric.sup++;if(p && isTitan(p.program))metric.titanApproved++;}
   else if(normalize(v.state)==='INCIDENCIA'){metric.incidences++;if(p && isTitan(p.program))metric.titanIncidences++;}
   else if(normalize(v.state)==='CANCELADA'){metric.cancelled++;if(p && isTitan(p.program))metric.titanCancelled++;}
  }
  if(normalize(v.state)==='APROBADA')daily.set(v.date,(daily.get(v.date)||0)+1);
 }
 for(const f of forecast) {
  if(wavePeriod(f.wave)!==period || !admin && f.user!==viewer)continue;
  const mapped=new Set(effectiveRoutes.filter(r=>r.user===f.user).map(r=>r.cda||cdaFor({route:r.route})));
  const cdaSet=mapped.size?mapped:userCdas.get(f.user)||new Set();
  const cda=integratedPlan?f.cda:(cdaSet.size===1?[...cdaSet][0]:'Forecast sin CDA');
  forecastCdas.set(f.user,cda);
  for(const metric of [total,get(byCda,cda),get(byAuditor,f.user)]){metric.fullForecast+=Number(f.forecast)||0;if(f.date<=cutoff)metric.forecast+=Number(f.forecast)||0;metric.forecastKnown=true;if(integratedPlan)metric.titanForecast=(metric.titanForecast||0)+(f.date<=cutoff?f.titanForecast:0);}
  if(f.date<=cutoff)plannedDaily.set(f.date,(plannedDaily.get(f.date)||0)+(Number(f.forecast)||0));
 }
 const usersWithVisits=new Set(visits.filter(v=>wavePeriod(v.wave)===period).map(v=>v.user));
 const targetUsers=new Set();
 for(const r of (integratedPlan?[]:routes)) {
  if(!r.user || !admin && r.user!==viewer)continue;
  if(r.closeDate)for(const m of [total,get(byCda,r.cda||cdaFor(r)),get(byAuditor,r.user)])m.closeDate=!m.closeDate||r.closeDate>m.closeDate?r.closeDate:m.closeDate;
  if(targetUsers.has(r.user))continue;
  targetUsers.add(r.user);
  if(r.titanForecast!==null && r.titanForecast!==undefined && r.titanForecast!=='') {
   const value=Number(r.titanForecast);if(Number.isFinite(value))for(const m of [total,get(byCda,r.cda||cdaFor(r)),get(byAuditor,r.user)])m.titanForecast=(m.titanForecast||0)+value;
  }
 }
 const finish=m=>{const pending=Math.max(0,m.quota-m.approved);const remainingDays=integratedPlan?new Set(forecast.filter(f=>f.fieldDay>currentFieldDay&&(m.key==='TOTAL'?(admin||f.user===viewer):byAuditor.get(m.key)===m?f.user===m.key:f.cda===m.key)).map(f=>f.fieldDay)).size:m.closeDate?new Set(forecast.filter(f=>wavePeriod(f.wave)===period&&f.date>cutoff&&f.date<=m.closeDate&&(m.key==='TOTAL'?admin||f.user===viewer:byAuditor.get(m.key)===m?f.user===m.key:forecastCdas.get(f.user)===m.key)).map(f=>f.date)).size:0;return {...m,pending,otherIncidences:Math.max(0,m.incidences-m.closedTemporary),incidenceRate:m.visited?m.incidences/m.visited:null,ctRate:m.visited?m.closedTemporary/m.visited:null,forecast:m.forecastKnown?m.forecast:null,gap:m.forecastKnown?m.approved-m.forecast:null,advance:m.quota?m.approved/m.quota:null,compliance:m.forecast?m.approved/m.forecast:null,titanPending:Math.max(0,m.titanQuota-m.titanApproved),titanGap:m.titanForecast===null?null:m.titanApproved-m.titanForecast,titanAdvance:m.titanQuota?m.titanApproved/m.titanQuota:null,quotaKnown:m.key==='TOTAL'?admin||assignedUsers.has(viewer):byAuditor.get(m.key)===m?assignedUsers.has(m.key):admin||assignedUsers.has(viewer),closeDate:m.closeDate||null,remainingDays,minProduction:integratedPlan?(pending===0?0:remainingDays?Math.ceil(pending/remainingDays):null):m.closeDate?(pending===0?0:remainingDays?Math.ceil(pending/remainingDays):null):null};};
 const weekly=new Map();const week=date=>{const d=new Date(date+'T12:00:00Z');d.setUTCDate(d.getUTCDate()-(d.getUTCDay()+6)%7);return d.toISOString().slice(0,10)};
 for(const [date,value] of daily){const key=week(date),w=weekly.get(key)||{date:key,approved:0,forecast:0};w.approved+=value;weekly.set(key,w)}
 for(const [date,value] of plannedDaily){const key=week(date),w=weekly.get(key)||{date:key,approved:0,forecast:0};w.forecast+=value;weekly.set(key,w)}
 return {integratedPlan,currentFieldDay,fieldSchedule:integratedPlan?Array.from({length:Math.max(planDays,fieldDates.length)},(_,i)=>{const fieldDay=i+1,date=fieldDates[i]||null,planned=forecast.filter(f=>f.fieldDay===fieldDay&&(admin||f.user===viewer));return {fieldDay,date,forecast:planned.reduce((n,f)=>n+f.forecast,0),titanForecast:planned.reduce((n,f)=>n+f.titanForecast,0),approved:date?daily.get(date)||0:0,observed:!!date&&date<=cutoff}}):[],total:finish(total),cdas:[...byCda.values()].map(finish).sort((a,b)=>a.name.localeCompare(b.name,'es')),auditors:[...byAuditor.values()].map(finish).sort((a,b)=>a.name.localeCompare(b.name,'es')),points,weekly:[...weekly.values()].sort((a,b)=>a.date.localeCompare(b.date)),daily:[...new Set([...daily.keys(),...plannedDaily.keys(),...dailyStates.keys()])].sort().map(date=>({date,value:daily.get(date)||0,forecast:plannedDaily.has(date)?plannedDaily.get(date):null,gap:plannedDaily.has(date)?(daily.get(date)||0)-plannedDaily.get(date):null,...(dailyStates.get(date)||{review:0,incidences:0,cancelled:0})})),unmatched:admin?unmatched:[],diagnostics:{unmappedMTs:admin&&integratedPlan?[...new Set(universe.filter(p=>!mtUsers.has(normalize(p.mt))).map(p=>p.mt))].sort():[],forecastUsersWithoutVisits:admin?[...new Set(forecast.filter(f=>wavePeriod(f.wave)===period&&!usersWithVisits.has(f.user)).map(f=>f.user))]:[],partialAssignments:unassignedRoutes.length>0,unassigned:total.unassigned,unmatched:unmatched.length,missingRoutes:!integratedPlan&&assignment.size===0,unassignedRouteCount:admin?unassignedRoutes.length:null,ambiguousRouteCount:admin?ambiguousRoutes.length:null,inferredRouteCount:admin?effectiveRoutes.filter(r=>r.inferred).length:null,ambiguousRoutes:admin?ambiguousRoutes:[],unassignedRoutes:admin?unassignedRoutes:[],titanForecastMissing:total.titanForecast===null}};
}


function validateRows(kind,rows) {
 if(!Array.isArray(rows)||!rows.length || rows.length>150000)throw new Error('La base debe contener entre 1 y 150.000 registros.');
 if(kind==='universe'&&rows.some(r=>r.mt||r.fieldDay!=null)&&rows.some(r=>!r.mt||!Number.isInteger(r.fieldDay)))throw new Error('El plan debe incluir MT y DIA en todos los puntos.');
 const seen=new Set();
 const targets=new Map();
 for(const row of rows) {
  if(!row || typeof row!=='object')throw new Error('Registro inválido.');
  const key=kind==='universe'?row.code:kind==='export'?`${wavePeriod(row.wave)}|${row.id}`:kind==='mappings'?`${row.mt}|${row.user}`:kind==='routes'?row.route:`${row.user}|${row.date}|${wavePeriod(row.wave)}`;
  if(!key || key==='undefined')throw new Error('Hay un registro sin identificador.');
  if(seen.has(key))throw new Error(`Identificador duplicado: ${key}.`);
  seen.add(key);
  for(const v of Object.values(row))if(typeof v==='string'&&v.length>5000)throw new Error('Hay una celda de más de 5.000 caracteres.');
  if(kind==='universe'&&(!row.code||typeof row.route!=='string'||typeof row.selection!=='string'||typeof row.program!=='string'))throw new Error('Universo incompleto.');
  if(kind==='universe'&&(row.mt||row.fieldDay!=null)&&(!/^[-A-Z0-9]{3,30}$/.test(row.mt)||!Number.isInteger(row.fieldDay)||row.fieldDay<1||row.fieldDay>366))throw new Error('Cada punto del plan debe tener MT y DIA entero positivo.');
  if(kind==='mappings'){if(!/^[-A-Z0-9]{3,30}$/.test(row.mt)||!/^[-a-z0-9._@]{1,100}$/.test(row.user))throw new Error('Homologación: completa MT y Usuario del export.');if(row.active!==undefined&&typeof row.active!=='boolean'||row.removed!==undefined&&typeof row.removed!=='boolean')throw new Error('Estado de auditor inválido.');}
  if(kind==='export'&&(!row.id||!row.code||!row.user||!/^\d{4}-\d{2}-\d{2}$/.test(row.date)||!wavePeriod(row.wave)))throw new Error('Export con identificador, usuario, fecha u ola inválidos.');
  if(kind==='forecast'&&(!row.user||!/^\d{4}-\d{2}-\d{2}$/.test(row.date)||!Number.isFinite(row.forecast)||row.forecast<0||!wavePeriod(row.wave)))throw new Error('Forecast con usuario, fecha, ola o meta inválidos.');
  if(kind==='routes'&&(!row.route||!row.user || row.titanForecast!=null&&(!Number.isFinite(row.titanForecast)||row.titanForecast<0)))throw new Error('Asignación con ruta, usuario o forecast inválidos.');
  if(kind==='routes'){
   if(row.closeDate && !/^\d{4}-\d{2}-\d{2}$/.test(row.closeDate))throw new Error('Fecha Cierre debe usar AAAA-MM-DD.');
   const target=JSON.stringify([row.titanForecast??null,row.closeDate||'']);
   if(targets.has(row.user)&&targets.get(row.user)!==target)throw new Error(`Forecast Titan o Fecha Cierre inconsistentes para ${row.user}. Repite la misma meta en sus rutas.`);
   targets.set(row.user,target);
  }
 }
 return true;
}

const BASE=Deno.env.get('SUPABASE_URL')!;
const SYNC_JOBS:Record<string,number>={export:577854098883515,forecast:873798021992995};
const SERVICE=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const codePassword=async(code:string)=>{const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode('lindley-code:'+code));return Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('')};
const newCode=async()=>{for(let i=0;i<20;i++){const letters='ABCDEFGHIJKLMNOPQRSTUVWXYZ';let prefix='';while(prefix.length<3){const value=crypto.getRandomValues(new Uint8Array(1))[0];if(value<234)prefix+=letters[value%26]}let value;do{value=crypto.getRandomValues(new Uint32Array(1))[0]}while(value>=4294967000);const code=prefix+String(value%1000).padStart(3,'0');const rows=await backend('/rest/v1/lindley_profiles?access_code=eq.'+code+'&select=id');if(!rows.length)return code}throw new HttpError(503,'No se pudo generar un código. Intenta nuevamente.')};
const ALLOWED=new Set(['https://reporting-dichterneira.github.io','http://127.0.0.1:5174','http://127.0.0.1:5173']);
class HttpError extends Error{constructor(public status:number,message:string){super(message)}}
const periodOf=(s:string|null)=>{if(!s||!/^20\d{2}-(0[1-9]|1[0-2])$/.test(s))throw new HttpError(400,'Mes inválido.');return s};
async function backend(path:string,options:RequestInit={}){const r=await fetch(BASE+path,{...options,headers:{apikey:SERVICE,Authorization:'Bearer '+SERVICE,'Content-Type':'application/json',...options.headers}});if(!r.ok){console.error('Backend failed',r.status,path.split('?')[0]);throw new HttpError(500,'No se pudo completar la operación en Supabase.')}const raw=await r.text();return raw?JSON.parse(raw):null}
async function authenticate(req:Request){const jwt=req.headers.get('authorization')||'';if(!/^Bearer [A-Za-z0-9_.-]+$/.test(jwt))throw new HttpError(401,'Ingresa para consultar el estudio.');const r=await fetch(BASE+'/auth/v1/user',{headers:{apikey:SERVICE,Authorization:jwt}});if(!r.ok)throw new HttpError(401,'La sesión expiró. Ingresa de nuevo.');const identity=await r.json();const rows=await backend('/rest/v1/lindley_profiles?id=eq.'+encodeURIComponent(identity.id)+'&active=eq.true&select=id,username,name,role,auditor');if(rows.length!==1)throw new HttpError(403,'Tu cuenta no tiene acceso a Lindley.');return rows[0]}
const body=async(req:Request)=>{const raw=await req.text();if(raw.length>40*1024*1024)throw new HttpError(413,'El archivo supera los 40 MB.');try{return JSON.parse(raw)}catch{throw new HttpError(400,'Contenido inválido.')}};
const encoder=(path:string)=>path.split('/').map(encodeURIComponent).join('/');
async function dataset(path:string){const r=await fetch(BASE+'/storage/v1/object/lindley-private/'+encoder(path),{headers:{apikey:SERVICE,Authorization:'Bearer '+SERVICE}});if(!r.ok)throw new HttpError(500,'No se pudo leer la base activa.');return r.json()}
async function saveDataset(kind:string,period:string,rows:any[],filename:string,userId:string|null=null){
 try{validateRows(kind,rows)}catch(e){throw new HttpError(400,(e as Error).message)}
 if(['export','forecast'].includes(kind)&&rows.some((r:any)=>wavePeriod(r.wave)!==period))throw new HttpError(400,'La base contiene registros de otro mes.');
 const path=period+'/'+kind+'/'+crypto.randomUUID()+'.json';
 const r=await fetch(BASE+'/storage/v1/object/lindley-private/'+path,{method:'POST',headers:{apikey:SERVICE,Authorization:'Bearer '+SERVICE,'Content-Type':'application/json'},body:JSON.stringify(rows)});if(!r.ok)throw new HttpError(500,'No se pudo guardar la base.');
 await backend('/rest/v1/rpc/lindley_activate_dataset',{method:'POST',body:JSON.stringify({p_period:period,p_kind:kind,p_path:path,p_count:rows.length,p_filename:filename,p_user:userId})});
 return {ok:true,rows:rows.length,period,kind};
}
async function databricksApi(path:string,payload?:any){
 const config=await dataset('integrations/databricks.json');
 const r=await fetch('https://adb-7299547680484260.0.azuredatabricks.net'+path,{method:payload?'POST':'GET',headers:{Authorization:'Bearer '+config.token,'Content-Type':'application/json'},body:payload?JSON.stringify(payload):undefined,signal:AbortSignal.timeout(30000)});
 if(!r.ok)throw new HttpError(502,'No se pudo iniciar o consultar Databricks. Revisa la conexión administrativa.');
 return r.json();
}
async function currentMappings(){const meta=await backend('/rest/v1/lindley_datasets?kind=eq.mappings&order=period.desc&select=path&limit=1');return meta.length?await dataset(meta[0].path):[]}
async function ensureAuditor(row:any){
 const profiles=await backend('/rest/v1/lindley_profiles?auditor=eq.'+encodeURIComponent(row.user)+'&select=id,role,active');
 if(profiles.length){if(profiles[0].role!=='auditor'||!profiles[0].active)throw new HttpError(400,'El usuario no tiene un acceso de auditor activo: '+row.user);return}
 const username='mt.'+row.mt.toLowerCase()+'.'+crypto.randomUUID().slice(0,8);
 const access_code=await newCode(),password=await codePassword(access_code);
 const account=await backend('/auth/v1/admin/users',{method:'POST',body:JSON.stringify({email:username+'@lindley.portal.invalid',password,email_confirm:true})});
 await backend('/rest/v1/lindley_profiles',{method:'POST',body:JSON.stringify({id:account.id,username,name:row.name||row.user,auditor:row.user,role:'auditor',access_code})});
}
Deno.serve(async(req:Request)=>{
 const origin=req.headers.get('origin')||'';
 const headers={'Content-Type':'application/json','Cache-Control':'no-store','Vary':'Origin','Access-Control-Allow-Origin':ALLOWED.has(origin)?origin:'https://reporting-dichterneira.github.io','Access-Control-Allow-Headers':'authorization,apikey,content-type','Access-Control-Allow-Methods':'GET,POST,OPTIONS','X-Content-Type-Options':'nosniff'};
 const reply=(value:any,status=200)=>new Response(JSON.stringify(value),{status,headers});
 if(origin&&!ALLOWED.has(origin))return reply({error:'Origen no autorizado.'},403);
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
 try{
  const url=new URL(req.url),route=url.pathname.split('/lindley-api/')[1]||'';
  if(route==='sync-forecast')throw new HttpError(410,'El forecast ahora se obtiene del universo MT/DIA.');
  if(['sync-export'].includes(route)&&req.method==='POST'){
   const token=req.headers.get('x-databricks-token')||'';
   if(!token||token.length>8192||/[\r\n]/.test(token))throw new HttpError(401,'Sin autorización para sincronizar.');
   const identityResponse=await fetch('https://adb-7299547680484260.0.azuredatabricks.net/api/2.0/preview/scim/v2/Me',{headers:{Authorization:'Bearer '+token},signal:AbortSignal.timeout(30000)});
   if(!identityResponse.ok)throw new HttpError(401,'Identidad de Databricks no válida.');
   const identity=await identityResponse.json();
   if(String(identity.userName).toLowerCase()!=='masanchez@dichter-neira.com'||identity.active===false)throw new HttpError(403,'La identidad no está habilitada para esta sincronización.');
   const input=await body(req),period=periodOf(input.period),kind=route==='sync-export'?'export':'forecast';
   if(input.kind!==kind||kind==='export'&&!/^(2026|2027)-/.test(period))throw new HttpError(400,'Base u ola no permitida para esta sincronización.');
   return reply(await saveDataset(kind,period,input.rows,'Databricks · '+(kind==='export'?'Lindley':'Forecast')+' · '+period+'.json'));
  }
  if(['code-login','admin-login'].includes(route)&&req.method==='POST'){
   if(Number(req.headers.get('content-length')||0)>2048)throw new HttpError(413,'Contenido demasiado grande.');
   const raw=await req.text();if(raw.length>2048)throw new HttpError(413,'Contenido demasiado grande.');let input:any;try{input=JSON.parse(raw)}catch{throw new HttpError(400,'Contenido inválido.')}
   let profile:any,password:string;
   if(route==='code-login'){
    const address=req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||'unknown';const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(address));const limiterKey=Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join('');
    const checkLimit=async(failed=false)=>backend('/rest/v1/rpc/lindley_code_limit',{method:'POST',body:JSON.stringify({p_key:limiterKey,p_failed:failed})});
    if(!await checkLimit())throw new HttpError(429,'Demasiados intentos incorrectos. Intenta nuevamente en 15 minutos.');
    const rejectCode=async()=>{await checkLimit(true);throw new HttpError(401,'Código incorrecto o acceso no habilitado.')};
    const code=String(input.code||'').trim().toUpperCase();if(!/^[-A-Z0-9]{3,30}$/.test(code))await rejectCode();
    const known=(await currentMappings()).filter((m:any)=>m.mt===code);
    const choices=known.filter((m:any)=>m.active!==false&&!m.removed);
    if(known.length&&!choices.length)await rejectCode();
    if(choices.length>1&&!input.auditor)return reply({selectAuditor:true,auditors:choices.map((m:any)=>({user:m.user,name:m.name||m.user}))});
    const mapped=choices.find((m:any)=>!input.auditor||m.user===input.auditor);
    if(choices.length&&!mapped)await rejectCode();
    const rows=await backend('/rest/v1/lindley_profiles?role=eq.auditor&active=eq.true&'+(mapped?'auditor=eq.'+encodeURIComponent(mapped.user):'access_code=eq.'+encodeURIComponent(code))+'&select=id,username,access_code');
    if(rows.length!==1)await rejectCode();profile=rows[0];password=await codePassword(profile.access_code);
   }else{
    const username=String(input.username||'').trim().toLowerCase();const rows=await backend('/rest/v1/lindley_profiles?role=eq.admin&active=eq.true&username=eq.'+encodeURIComponent(username)+'&select=id,username');
    if(rows.length!==1)throw new HttpError(401,'Usuario o contraseña incorrectos.');profile=rows[0];password=String(input.password||'');
   }
   const r=await fetch(BASE+'/auth/v1/token?grant_type=password',{method:'POST',headers:{apikey:SERVICE,'Content-Type':'application/json'},body:JSON.stringify({email:profile.username+'@lindley.portal.invalid',password})});
   if(!r.ok)throw new HttpError(401,route==='code-login'?'Código incorrecto o acceso no habilitado.':'Usuario o contraseña incorrectos.');const session=await r.json();if(session.user?.id!==profile.id)throw new HttpError(401,'Acceso no habilitado.');return reply(session);
  }
  const user=await authenticate(req),admin=user.role==='admin';
  if(route==='dashboard'&&req.method==='GET'){
   const period=periodOf(url.searchParams.get('period')),cutoff=url.searchParams.get('cutoff')||period+'-31';if(!/^\d{4}-\d{2}-\d{2}$/.test(cutoff))throw new HttpError(400,'Fecha de corte inválida.');
   const metadata=await backend('/rest/v1/lindley_datasets?period=eq.'+period+'&select=*');
   const bases:any={universe:[],export:[],forecast:[],routes:[],mappings:[]};
   await Promise.all(metadata.map(async(m:any)=>{bases[m.kind]=await dataset(m.path)}));
   const membership=bases.mappings.filter((m:any)=>m.user===user.auditor);
   if(!admin&&membership.length&&!membership.some((m:any)=>m.active!==false&&!m.removed))throw new HttpError(403,'Tu acceso no está activo en este mes. Consulta al administrador.');
   const accounts=await backend('/rest/v1/lindley_profiles?active=eq.true&select=auditor,name');
   const result=calculateStudy({universe:bases.universe,visits:bases.export,forecast:bases.forecast,routes:bases.routes,mappings:bases.mappings,accounts,period,cutoff,viewer:admin?null:user.auditor});
   const history=admin?await backend('/rest/v1/lindley_imports?period=eq.'+period+'&select=kind,filename,row_count,uploaded_at&order=uploaded_at.desc&limit=30'):[];
   const allPeriods=await backend('/rest/v1/lindley_datasets?select=period&order=period.desc');
   const state=url.searchParams.get('state')||'',query=(url.searchParams.get('q')||'').trim().toLowerCase();const page=Math.max(1,Math.min(10000,Number(url.searchParams.get('page'))||1));
   const points=result.points.filter((p:any)=>(!state||state==='titan'?state!=='titan'||p.titan:p.state===state)&&(!query||[p.code,p.name,p.route,p.cda].some(v=>String(v).toLowerCase().includes(query))));
   return reply({...result,points:points.slice((page-1)*100,page*100),pointCount:points.length,page,periods:[...new Set(allPeriods.map((r:any)=>r.period))],period,cutoff,routeAssignments:admin?bases.routes:[],mtMappings:admin?bases.mappings:[],mappingVersion:admin?metadata.find((m:any)=>m.kind==='mappings')?.path||'':undefined,user:{name:user.name,email:user.username+'@lindley.portal.invalid',role:user.role,auditor:user.auditor},imports:history});
  }
  if(!admin)throw new HttpError(403,'Esta acción requiere acceso administrativo.');
  if(route==='monthly-auditors'&&req.method==='POST'){
   const input=await body(req),period=periodOf(input.period),action=String(input.action||''),auditor=String(input.auditor||'').trim().toLowerCase();
   if(!/^[-a-z0-9._@]{1,100}$/.test(auditor)||!['add','status','remove','restore'].includes(action))throw new HttpError(400,'Auditor o acción inválidos.');
   const meta=await backend('/rest/v1/lindley_datasets?period=eq.'+period+'&kind=eq.mappings&select=path');
   if(String(input.version||'')!==(meta[0]?.path||''))throw new HttpError(409,'La lista cambió. Actualiza el portal antes de guardar.');
   let rows:any[]=meta.length?await dataset(meta[0].path):[];
   if(action==='add'){
    const name=String(input.name||'').trim(),mts=[...new Set(String(input.mts||'').toUpperCase().split(/[\s,;]+/).filter(Boolean))];
    if(!name||name.length>150||!mts.length||mts.length>30||mts.some(mt=>!/^[-A-Z0-9]{3,30}$/.test(mt)))throw new HttpError(400,'Completa el nombre, usuario del export y MT válidos. Separa varios MT con comas.');
    const additions=mts.map(mt=>({mt,user:auditor,name,active:true,removed:false}));validateRows('mappings',additions);
    await ensureAuditor(additions[0]);
    for(const row of additions){const i=rows.findIndex(m=>m.mt===row.mt&&m.user===auditor);if(i<0)rows.push(row);else rows[i]={...rows[i],...row};}
    await backend('/rest/v1/lindley_profiles?role=eq.auditor&auditor=eq.'+encodeURIComponent(auditor),{method:'PATCH',body:JSON.stringify({name})});
   }else{
    if(!rows.some(m=>m.user===auditor))throw new HttpError(404,'El auditor no pertenece al mes seleccionado.');
    if(action==='status'&&typeof input.active!=='boolean')throw new HttpError(400,'Selecciona el estado activo del mes.');
    rows=rows.map(m=>m.user!==auditor?m:action==='remove'?{...m,active:false,removed:true}:action==='restore'?{...m,active:true,removed:false}:{...m,active:input.active});
   }
   return reply(await saveDataset('mappings',period,rows,'Gestión manual de auditores · '+action,user.id));
  }
  if(route==='refresh-forecast')throw new HttpError(410,'El forecast se calcula desde el universo con MT y DIA.');
  if(['refresh-export'].includes(route)&&req.method==='GET'){
   const kind=route==='refresh-export'?'export':'forecast';
   const rows=await backend('/rest/v1/lindley_sync_requests?kind=eq.'+kind+'&select=id,status,created_at,finished_at,run_id,job_id&order=created_at.desc&limit=1');
   const current=rows[0];
   if(current?.status==='pending'&&current.run_id){
    const run=await databricksApi('/api/2.2/jobs/runs/get?run_id='+current.run_id);
    if(run.job_id!==SYNC_JOBS[kind]||current.job_id!==SYNC_JOBS[kind])throw new HttpError(502,'La ejecución no corresponde a la base solicitada.');
    if(['TERMINATED','SKIPPED','INTERNAL_ERROR'].includes(run.state?.life_cycle_state)){
     current.status=run.state.result_state==='SUCCESS'?'completed':'failed';current.finished_at=new Date().toISOString();
     await backend('/rest/v1/lindley_sync_requests?id=eq.'+current.id,{method:'PATCH',body:JSON.stringify({status:current.status,finished_at:current.finished_at})});
    }
   }
   return reply(rows);
  }
  if(['refresh-export'].includes(route)&&req.method==='POST'){
   const kind=route==='refresh-export'?'export':'forecast',id=crypto.randomUUID();
   // Reserve before starting the job: concurrent clicks cannot create duplicate runs.
   const reserved=await fetch(BASE+'/rest/v1/lindley_sync_requests',{method:'POST',headers:{apikey:SERVICE,Authorization:'Bearer '+SERVICE,'Content-Type':'application/json'},body:JSON.stringify({id,kind,job_id:SYNC_JOBS[kind],requested_by:user.id})});
   if(reserved.status===409)return reply({ok:true,pending:true});
   if(!reserved.ok)throw new HttpError(500,'No se pudo registrar la actualización.');
   try{
    // Always request history. A running current-month job must not replace this request.
    const run=await databricksApi('/api/2.2/jobs/run-now',{job_id:SYNC_JOBS[kind],idempotency_token:id,job_parameters:{dry_run:'false',dataset:kind,scope:'history'}});
    await backend('/rest/v1/lindley_sync_requests?id=eq.'+id,{method:'PATCH',body:JSON.stringify({run_id:run.run_id})});
   }catch(e){await backend('/rest/v1/lindley_sync_requests?id=eq.'+id,{method:'PATCH',body:JSON.stringify({status:'failed',finished_at:new Date().toISOString()})});throw e}
   return reply({ok:true,pending:true});
  }
  if(route==='import'&&req.method==='POST'){
   const input=await body(req),period=periodOf(input.period),kind=input.kind;
   if(!['universe','export','forecast','routes','mappings'].includes(kind))throw new HttpError(400,'Tipo de base inválido.');
   if(kind==='mappings'){
    try{validateRows(kind,input.rows)}catch(e){throw new HttpError(400,(e as Error).message)}
    const meta=await backend('/rest/v1/lindley_datasets?period=eq.'+period+'&kind=eq.universe&select=path');if(!meta.length)throw new HttpError(400,'Carga primero el universo del mes.');
    const universe=await dataset(meta[0].path),mts=new Set(universe.map((p:any)=>p.mt));
    for(const row of input.rows)if(!mts.has(row.mt))throw new HttpError(400,'MT no existe en el universo del mes: '+row.mt);
    for(const row of input.rows)await ensureAuditor(row);
   }
   return reply(await saveDataset(kind,period,input.rows,String(input.filename||kind+'.json').slice(0,255),user.id));
  }
  if(route==='users'&&req.method==='GET'){
   const profiles=await backend('/rest/v1/lindley_profiles?select=username,name,auditor,role,active,access_code&order=name');
   const metadata=await backend('/rest/v1/lindley_datasets?kind=in.(export,forecast)&order=period.desc&select=path,kind,period');const latest=metadata[0]?.period;const seen=new Set(profiles.map((p:any)=>p.auditor));
   for(const m of metadata.filter((m:any)=>m.period===latest)){for(const row of await dataset(m.path)){const auditor=String(row.user||'').trim().toLowerCase();if(auditor&&!seen.has(auditor)){profiles.push({name:auditor,auditor,role:'auditor',active:false,username:null,access_code:null});seen.add(auditor)}}}
   const mappings=(await currentMappings()).filter((m:any)=>m.active!==false&&!m.removed);return reply(profiles.map((p:any)=>({...p,mt:mappings.find((m:any)=>m.user===p.auditor)?.mt||'',mts:mappings.filter((m:any)=>m.user===p.auditor).map((m:any)=>m.mt),access_code:mappings.find((m:any)=>m.user===p.auditor)?.mt||null})));
  }
  if(route==='users'&&req.method==='POST'){
   const input=await body(req),username=String(input.username||'').trim().toLowerCase(),auditor=String(input.auditor||'').trim().toLowerCase(),name=String(input.name||'').trim();
   if(!/^[a-z0-9._-]{3,50}$/.test(username)||!/^[-a-z0-9._@]{1,100}$/.test(auditor)||!name||name.length>150)throw new HttpError(400,'Completa nombre, usuario (3 a 50 letras, números o puntos) y usuario del export.');
   const existing=await backend('/rest/v1/lindley_profiles?or=(username.eq.'+encodeURIComponent(username)+',auditor.eq.'+encodeURIComponent(auditor)+')&select=id');if(existing.length)throw new HttpError(409,'Ese usuario o auditor ya tiene un acceso.');
   const access_code=await newCode(),password=await codePassword(access_code);
   const account=await backend('/auth/v1/admin/users',{method:'POST',body:JSON.stringify({email:username+'@lindley.portal.invalid',password,email_confirm:true})});
   try{await backend('/rest/v1/lindley_profiles',{method:'POST',body:JSON.stringify({id:account.id,username,name,auditor,role:'auditor',access_code})})}catch(e){console.error('Profile creation failed for auth account',account.id);throw e}return reply({ok:true,access_code});
  }
  throw new HttpError(404,'Acción no encontrada.');
 }catch(e){return reply({error:e instanceof HttpError?e.message:'No se pudo procesar la solicitud.'},e instanceof HttpError?e.status:500)}
});
