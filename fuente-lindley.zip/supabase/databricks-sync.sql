create table if not exists public.lindley_sync_requests (
 id uuid primary key default gen_random_uuid(),
 requested_by uuid references auth.users(id),
 status text not null default 'pending' check(status in ('pending','completed','failed')),
 created_at timestamptz not null default now(),
 finished_at timestamptz
);
alter table public.lindley_sync_requests enable row level security;
revoke all on public.lindley_sync_requests from anon, authenticated;
grant all on public.lindley_sync_requests to service_role;
create unique index if not exists lindley_sync_one_pending on public.lindley_sync_requests(status) where status='pending';

alter table public.lindley_sync_requests add column if not exists run_id bigint;
