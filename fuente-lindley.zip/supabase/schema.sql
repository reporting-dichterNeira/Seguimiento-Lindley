-- Lindley uses isolated tables; existing portal tables and policies are untouched.
begin;
create table if not exists public.lindley_profiles (
 id uuid primary key references auth.users(id), username text unique not null,
 name text not null, role text not null check(role in ('admin','auditor')),
 auditor text, active boolean not null default true,
 check(role='admin' or coalesce(auditor,'')<>'')
);
create table if not exists public.lindley_datasets (
 period text not null check(period ~ '^20[0-9]{2}-(0[1-9]|1[0-2])$'),
 kind text not null check(kind in ('universe','export','forecast','routes')),
 path text not null, row_count integer not null check(row_count>0), filename text not null,
 uploaded_at timestamptz not null default now(), uploaded_by uuid references auth.users(id),
 primary key(period,kind)
);
create table if not exists public.lindley_imports (
 id uuid primary key default gen_random_uuid(), period text not null, kind text not null,
 path text not null, row_count integer not null, filename text not null,
 uploaded_at timestamptz not null default now(), uploaded_by uuid references auth.users(id)
);
create index if not exists lindley_imports_period_date on public.lindley_imports(period,uploaded_at desc);
alter table public.lindley_profiles enable row level security;
alter table public.lindley_datasets enable row level security;
alter table public.lindley_imports enable row level security;
revoke all on public.lindley_profiles,public.lindley_datasets,public.lindley_imports from public,anon,authenticated;
grant select,insert,update,delete on public.lindley_profiles,public.lindley_datasets,public.lindley_imports to service_role;
create or replace function public.lindley_activate_dataset(p_period text,p_kind text,p_path text,p_count integer,p_filename text,p_user uuid)
returns void language plpgsql security invoker set search_path=public as $$
begin
 insert into public.lindley_imports(period,kind,path,row_count,filename,uploaded_by) values(p_period,p_kind,p_path,p_count,p_filename,p_user);
 insert into public.lindley_datasets(period,kind,path,row_count,filename,uploaded_by) values(p_period,p_kind,p_path,p_count,p_filename,p_user)
 on conflict(period,kind) do update set path=excluded.path,row_count=excluded.row_count,filename=excluded.filename,uploaded_at=now(),uploaded_by=excluded.uploaded_by;
end; $$;
revoke all on function public.lindley_activate_dataset(text,text,text,integer,text,uuid) from public,anon,authenticated;
grant execute on function public.lindley_activate_dataset(text,text,text,integer,text,uuid) to service_role;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
 values('lindley-private','lindley-private',false,41943040,array['application/json']) on conflict(id) do nothing;
create policy lindley_private_objects on storage.objects as restrictive for all to anon,authenticated using (bucket_id <> 'lindley-private') with check (bucket_id <> 'lindley-private');
commit;
select tablename,rowsecurity from pg_tables where schemaname='public' and tablename like 'lindley_%';
