const BASE=Deno.env.get('SUPABASE_URL')!;
const SYNC_JOBS:Record<string,number>={export:577854098883515,forecast:873798021992995};
const SERVICE=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const codePassword=async(code:string)=>{const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode('lindley-code:'+code));return Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('')};
const newCode=async()=>{for(let i=0;i<20;i++){const letters='ABCDEFGHIJKLMNOPQRSTUVWXYZ';let prefix='';while(prefix.length<3){const value=crypto.getRandomValues(new Uint8Array(1))[0];if(value<234)prefix+=letters[value%26]}let value;do{value=crypto.getRandomValues(new Uint32Array(1))[0]}while(value>=4294967000);const code=prefix+String(value%1000).padStart(3,'0');const rows=await backend('/rest/v1/lindley_profiles?access_code=eq.'+code+'&select=id');if(!rows.length)return code}throw new HttpError(503,'No se pudo generar un código. Intenta nuevamente.')};
const ALLOWED=new Set(['https://reporting-dichterneira.github.io','https://seguimiento-lindley.vercel.app','http://127.0.0.1:5174','http://127.0.0.1:5173']);
class HttpError extends Error{constructor(public status:number,message:string){super(message)}}
const periodOf=(s:string|null)=>{if(!s||!/^20\d{2}-(0[1-9]|1[0-2])$/.test(s))throw new HttpError(400,'Mes inválido.');return s};
async function backend(path:string,options:RequestInit={}){const r=await fetch(BASE+path,{...options,headers:{apikey:SERVICE,Authorization:'Bearer '+SERVICE,'Content-Type':'application/json',...options.headers}});if(!r.ok){console.error('Backend failed',r.status,path.split('?')[0]);throw new HttpError(500,'No se pudo completar la operación en Supabase.')}const raw=await r.text();return raw?JSON.parse(raw):null}
async function authenticate(req:Request){const jwt=req.headers.get('authorization')||'';if(!/^Bearer [A-Za-z0-9_.-]+$/.test(jwt))throw new HttpError(401,'Ingresa para consultar el estudio.');const r=await fetch(BASE+'/auth/v1/user',{headers:{apikey:SERVICE,Authorization:jwt}});if(!r.ok)throw new HttpError(401,'La sesión expiró. Ingresa de nuevo.');const identity=await r.json();const rows=await backend('/rest/v1/lindley_profiles?id=eq.'+encodeURIComponent(identity.id)+'&active=eq.true&select=id,username,name,role,auditor');if(rows.length!==1)throw new HttpError(403,'Tu cuenta no tiene acceso a Lindley.');return rows[0]}
const body=async(req:Request)=>{const raw=await req.text();if(raw.length>40*1024*1024)throw new HttpError(413,'El archivo supera los 40 MB.');try{return JSON.parse(raw)}catch{throw new HttpError(400,'Contenido inválido.')}};
const encoder=(path:string)=>path.split('/').map(encodeURIComponent).join('/');
async function dataset(path:string){const r=await fetch(BASE+'/storage/v1/object/lindley-private/'+encoder(path),{headers:{apikey:SERVICE,Authorization:'Bearer '+SERVICE}});if(!r.ok)throw new HttpError(500,'No se pudo leer la base activa.');return r.json()}
async function saveDataset(kind:string,period:string,rows:any[],filename:string,userId:string|null=null,version:string=''){
 try{validateRows(kind,rows)}catch(e){throw new HttpError(400,(e as Error).message)}
 if(['export','forecast'].includes(kind)&&rows.some((r:any)=>wavePeriod(r.wave)!==period))throw new HttpError(400,'La base contiene registros de otro mes.');
 const path=period+'/'+kind+'/'+crypto.randomUUID()+'.json';
 const r=await fetch(BASE+'/storage/v1/object/lindley-private/'+path,{method:'POST',headers:{apikey:SERVICE,Authorization:'Bearer '+SERVICE,'Content-Type':'application/json'},body:JSON.stringify(rows)});if(!r.ok)throw new HttpError(500,'No se pudo guardar la base.');
 if(kind==='calendar'){
  const activated=await backend('/rest/v1/rpc/lindley_activate_calendar',{method:'POST',body:JSON.stringify({p_period:period,p_path:path,p_count:rows.length,p_user:userId,p_version:version})});
  if(!activated)throw new HttpError(409,'El calendario cambió. Actualiza el portal antes de guardar.');
 }else await backend('/rest/v1/rpc/lindley_activate_dataset',{method:'POST',body:JSON.stringify({p_period:period,p_kind:kind,p_path:path,p_count:rows.length,p_filename:filename,p_user:userId})});
 return {ok:true,rows:rows.length,period,kind};
}
async function databricksApi(path:string,payload?:any){
 const config=await dataset('integrations/databricks.json');
 const r=await fetch('https://adb-7299547680484260.0.azuredatabricks.net'+path,{method:payload?'POST':'GET',headers:{Authorization:'Bearer '+config.token,'Content-Type':'application/json'},body:payload?JSON.stringify(payload):undefined,signal:AbortSignal.timeout(30000)});
 if(!r.ok)throw new HttpError(502,'No se pudo iniciar o consultar Databricks. Revisa la conexión administrativa.');
 return r.json();
}
async function currentMappings(){const meta=await backend('/rest/v1/lindley_datasets?kind=eq.mappings&order=period.desc&select=path&limit=1');return meta.length?await dataset(meta[0].path):[]}
async function ensureAuditor(row:any){
 const profiles=await backend('/rest/v1/lindley_profiles?auditor=eq.'+encodeURIComponent(row.user)+'&select=id,role,active');
 if(profiles.length){if(profiles[0].role!=='auditor'||!profiles[0].active)throw new HttpError(400,'El usuario no tiene un acceso de auditor activo: '+row.user);return}
 const username='mt.'+row.mt.toLowerCase()+'.'+crypto.randomUUID().slice(0,8);
 const access_code=await newCode(),password=await codePassword(access_code);
 const account=await backend('/auth/v1/admin/users',{method:'POST',body:JSON.stringify({email:username+'@lindley.portal.invalid',password,email_confirm:true})});
 await backend('/rest/v1/lindley_profiles',{method:'POST',body:JSON.stringify({id:account.id,username,name:row.name||row.user,auditor:row.user,role:'auditor',access_code})});
}
Deno.serve(async(req:Request)=>{
 const origin=req.headers.get('origin')||'';
 const headers={'Content-Type':'application/json','Cache-Control':'no-store','Vary':'Origin','Access-Control-Allow-Origin':ALLOWED.has(origin)?origin:'https://reporting-dichterneira.github.io','Access-Control-Allow-Headers':'authorization,apikey,content-type','Access-Control-Allow-Methods':'GET,POST,OPTIONS','X-Content-Type-Options':'nosniff'};
 const reply=(value:any,status=200)=>new Response(JSON.stringify(value),{status,headers});
 if(origin&&!ALLOWED.has(origin))return reply({error:'Origen no autorizado.'},403);
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
 try{
  const url=new URL(req.url),route=url.pathname.split('/lindley-api/')[1]||'';
  if(route==='sync-forecast')throw new HttpError(410,'El forecast ahora se obtiene del universo MT/DIA.');
  if(['sync-export'].includes(route)&&req.method==='POST'){
   const token=req.headers.get('x-databricks-token')||'';
   if(!token||token.length>8192||/[\r\n]/.test(token))throw new HttpError(401,'Sin autorización para sincronizar.');
   const identityResponse=await fetch('https://adb-7299547680484260.0.azuredatabricks.net/api/2.0/preview/scim/v2/Me',{headers:{Authorization:'Bearer '+token},signal:AbortSignal.timeout(30000)});
   if(!identityResponse.ok)throw new HttpError(401,'Identidad de Databricks no válida.');
   const identity=await identityResponse.json();
   if(String(identity.userName).toLowerCase()!=='masanchez@dichter-neira.com'||identity.active===false)throw new HttpError(403,'La identidad no está habilitada para esta sincronización.');
   const input=await body(req),period=periodOf(input.period),kind=route==='sync-export'?'export':'forecast';
   if(input.kind!==kind||kind==='export'&&!/^(2026|2027)-/.test(period))throw new HttpError(400,'Base u ola no permitida para esta sincronización.');
   return reply(await saveDataset(kind,period,input.rows,'Databricks · '+(kind==='export'?'Lindley':'Forecast')+' · '+period+'.json'));
  }
  if(['code-login','admin-login'].includes(route)&&req.method==='POST'){
   if(Number(req.headers.get('content-length')||0)>2048)throw new HttpError(413,'Contenido demasiado grande.');
   const raw=await req.text();if(raw.length>2048)throw new HttpError(413,'Contenido demasiado grande.');let input:any;try{input=JSON.parse(raw)}catch{throw new HttpError(400,'Contenido inválido.')}
   let profile:any,password:string;
   if(route==='code-login'){
    const address=req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||'unknown';const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(address));const limiterKey=Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join('');
    const checkLimit=async(failed=false)=>backend('/rest/v1/rpc/lindley_code_limit',{method:'POST',body:JSON.stringify({p_key:limiterKey,p_failed:failed})});
    if(!await checkLimit())throw new HttpError(429,'Demasiados intentos incorrectos. Intenta nuevamente en 15 minutos.');
    const rejectCode=async()=>{await checkLimit(true);throw new HttpError(401,'Código incorrecto o acceso no habilitado.')};
    const code=String(input.code||'').trim().toUpperCase();if(!/^[-A-Z0-9]{3,30}$/.test(code))await rejectCode();
    const known=(await currentMappings()).filter((m:any)=>m.mt===code);
    const choices=known.filter((m:any)=>m.active!==false&&!m.removed);
    if(known.length&&!choices.length)await rejectCode();
    if(choices.length>1&&!input.auditor)return reply({selectAuditor:true,auditors:choices.map((m:any)=>({user:m.user,name:m.name||m.user}))});
    const mapped=choices.find((m:any)=>!input.auditor||m.user===input.auditor);
    if(choices.length&&!mapped)await rejectCode();
    const rows=await backend('/rest/v1/lindley_profiles?role=eq.auditor&active=eq.true&'+(mapped?'auditor=eq.'+encodeURIComponent(mapped.user):'access_code=eq.'+encodeURIComponent(code))+'&select=id,username,access_code');
    if(rows.length!==1)await rejectCode();profile=rows[0];password=await codePassword(profile.access_code);
   }else{
    const username=String(input.username||'').trim().toLowerCase();const rows=await backend('/rest/v1/lindley_profiles?role=eq.admin&active=eq.true&username=eq.'+encodeURIComponent(username)+'&select=id,username');
    if(rows.length!==1)throw new HttpError(401,'Usuario o contraseña incorrectos.');profile=rows[0];password=String(input.password||'');
   }
   const r=await fetch(BASE+'/auth/v1/token?grant_type=password',{method:'POST',headers:{apikey:SERVICE,'Content-Type':'application/json'},body:JSON.stringify({email:profile.username+'@lindley.portal.invalid',password})});
   if(!r.ok)throw new HttpError(401,route==='code-login'?'Código incorrecto o acceso no habilitado.':'Usuario o contraseña incorrectos.');const session=await r.json();if(session.user?.id!==profile.id)throw new HttpError(401,'Acceso no habilitado.');return reply(session);
  }
  const user=await authenticate(req),admin=user.role==='admin';
  if(['dashboard','point-export'].includes(route)&&req.method==='GET'){
   const period=periodOf(url.searchParams.get('period')),cutoff=url.searchParams.get('cutoff')||period+'-31';if(!/^\d{4}-\d{2}-\d{2}$/.test(cutoff))throw new HttpError(400,'Fecha de corte inválida.');
   const metadata=await backend('/rest/v1/lindley_datasets?period=eq.'+period+'&select=*');
   const bases:any={universe:[],export:[],forecast:[],routes:[],mappings:[],calendar:[],'linear-forecast':[],'field-forecast':[]};
   await Promise.all(metadata.map(async(m:any)=>{bases[m.kind]=await dataset(m.path)}));
   const membership=bases.mappings.filter((m:any)=>m.user===user.auditor);
   if(!admin&&membership.length&&!membership.some((m:any)=>m.active!==false&&!m.removed))throw new HttpError(403,'Tu acceso no está activo en este mes. Consulta al administrador.');
   const accounts=await backend('/rest/v1/lindley_profiles?active=eq.true&select=auditor,name');
   const result=calculateStudy({universe:bases.universe,visits:bases.export,forecast:bases.forecast,routes:bases.routes,mappings:bases.mappings,calendar:bases.calendar,accounts,period,cutoff,viewer:admin?null:user.auditor});
   const field=admin?calculateFieldForecast({rows:bases['field-forecast'],cdas:result.cdas,period,cutoff}):null;
   if(field){result.cdas=field.cdas;Object.assign(result.total,{fieldForecast:field.summary.forecast,fieldEffective:field.summary.effective,fieldGap:field.summary.gap});}
   const history=admin?await backend('/rest/v1/lindley_imports?period=eq.'+period+'&select=kind,filename,row_count,uploaded_at&order=uploaded_at.desc&limit=30'):[];
   const allPeriods=await backend('/rest/v1/lindley_datasets?select=period&order=period.desc');
   const state=url.searchParams.get('state')||'',query=(url.searchParams.get('q')||'').trim().toLowerCase();const page=Math.max(1,Math.min(10000,Number(url.searchParams.get('page'))||1));
   const filters={state,q:query,program:url.searchParams.get('program')||'',selection:url.searchParams.get('selection')||'',states:url.searchParams.getAll('states')};
   const points=result.points.filter((p:any)=>matchesPointFilters(p,filters));
   if(route==='point-export')return reply({points,pointCount:points.length,period,cutoff});
   return reply({...result,fieldForecast:admin?field?.summary||null:undefined,linearForecast:admin?calculateLinearForecast({rows:bases['linear-forecast'],period,cutoff,effective:result.total.effective}):undefined,points:points.slice((page-1)*100,page*100),pointCount:points.length,page,periods:[...new Set(allPeriods.map((r:any)=>r.period))],period,cutoff,routeAssignments:admin?bases.routes:[],mtMappings:admin?bases.mappings:[],mappingVersion:admin?metadata.find((m:any)=>m.kind==='mappings')?.path||'':undefined,calendarVersion:admin?metadata.find((m:any)=>m.kind==='calendar')?.path||'':undefined,user:{name:user.name,email:user.username+'@lindley.portal.invalid',role:user.role,auditor:user.auditor},imports:history});
  }
  if(!admin)throw new HttpError(403,'Esta acción requiere acceso administrativo.');
  if(route==='field-calendar'&&req.method==='POST'){
   const input=await body(req),period=periodOf(input.period);
   try{validateRows('calendar',input.rows)}catch(e){throw new HttpError(400,(e as Error).message)}
   const rows=input.rows.map((r:any)=>({date:r.date,mode:r.mode}));
   const meta=await backend('/rest/v1/lindley_datasets?period=eq.'+period+'&kind=eq.calendar&select=path');
   if(String(input.version||'')!==(meta[0]?.path||''))throw new HttpError(409,'El calendario cambió. Actualiza el portal antes de guardar.');
   return reply(await saveDataset('calendar',period,rows,'Calendario de días de campo',user.id,String(input.version||'')));
  }
  if(route==='monthly-auditors'&&req.method==='POST'){
   const input=await body(req),period=periodOf(input.period),action=String(input.action||''),auditor=String(input.auditor||'').trim().toLowerCase();
   if(!/^[-a-z0-9._@]{1,100}$/.test(auditor)||!['add','edit','status','remove','restore'].includes(action))throw new HttpError(400,'Auditor o acción inválidos.');
   const meta=await backend('/rest/v1/lindley_datasets?period=eq.'+period+'&kind=eq.mappings&select=path');
   if(String(input.version||'')!==(meta[0]?.path||''))throw new HttpError(409,'La lista cambió. Actualiza el portal antes de guardar.');
   let rows:any[]=meta.length?await dataset(meta[0].path):[];
   if(action==='add'){
    const name=String(input.name||'').trim(),mts=[...new Set(String(input.mts||'').toUpperCase().split(/[\s,;]+/).filter(Boolean))];
    if(!name||name.length>150||!mts.length||mts.length>30||mts.some(mt=>!/^[-A-Z0-9]{3,30}$/.test(mt)))throw new HttpError(400,'Completa el nombre, usuario del export y MT válidos. Separa varios MT con comas.');
    const additions=mts.map(mt=>({mt,user:auditor,name,active:true,removed:false}));validateRows('mappings',additions);
    await ensureAuditor(additions[0]);
    for(const row of additions){const i=rows.findIndex(m=>m.mt===row.mt&&m.user===auditor);if(i<0)rows.push(row);else rows[i]={...rows[i],...row};}
    await backend('/rest/v1/lindley_profiles?role=eq.auditor&auditor=eq.'+encodeURIComponent(auditor),{method:'PATCH',body:JSON.stringify({name})});
   }else if(action==='edit'){
    const previous=rows.filter(m=>m.user===auditor);
    if(!previous.length)throw new HttpError(404,'El auditor no pertenece al mes seleccionado.');
    const mts=[...new Set(String(input.mts||'').toUpperCase().split(/[\s,;]+/).filter(Boolean))];
    if(!mts.length||mts.length>30||mts.some(mt=>!/^[-A-Z0-9]{3,30}$/.test(mt)))throw new HttpError(400,'Escribe entre 1 y 30 MT válidos, separados por comas.');
    const active=previous.some(m=>m.active!==false&&!m.removed),removed=previous.every(m=>!!m.removed);
    const replacements=mts.map(mt=>({...(previous.find(m=>m.mt===mt)||previous[0]),mt,user:auditor,active,removed}));
    validateRows('mappings',replacements);
    rows=[...rows.filter(m=>m.user!==auditor),...replacements];
   }else{
    if(!rows.some(m=>m.user===auditor))throw new HttpError(404,'El auditor no pertenece al mes seleccionado.');
    if(action==='status'&&typeof input.active!=='boolean')throw new HttpError(400,'Selecciona el estado activo del mes.');
    rows=rows.map(m=>m.user!==auditor?m:action==='remove'?{...m,active:false,removed:true}:action==='restore'?{...m,active:true,removed:false}:{...m,active:input.active});
   }
   return reply(await saveDataset('mappings',period,rows,'Gestión manual de auditores · '+action,user.id));
  }
  if(route==='refresh-forecast')throw new HttpError(410,'El forecast se calcula desde el universo con MT y DIA.');
  if(['refresh-export'].includes(route)&&req.method==='GET'){
   const kind=route==='refresh-export'?'export':'forecast';
   const rows=await backend('/rest/v1/lindley_sync_requests?kind=eq.'+kind+'&select=id,status,created_at,finished_at,run_id,job_id&order=created_at.desc&limit=1');
   const current=rows[0];
   if(current?.status==='pending'&&current.run_id){
    const run=await databricksApi('/api/2.2/jobs/runs/get?run_id='+current.run_id);
    if(run.job_id!==SYNC_JOBS[kind]||current.job_id!==SYNC_JOBS[kind])throw new HttpError(502,'La ejecución no corresponde a la base solicitada.');
    if(['TERMINATED','SKIPPED','INTERNAL_ERROR'].includes(run.state?.life_cycle_state)){
     current.status=run.state.result_state==='SUCCESS'?'completed':'failed';current.finished_at=new Date().toISOString();
     await backend('/rest/v1/lindley_sync_requests?id=eq.'+current.id,{method:'PATCH',body:JSON.stringify({status:current.status,finished_at:current.finished_at})});
    }
   }
   const period=periodOf(url.searchParams.get('period'));
   const loads=await backend('/rest/v1/lindley_datasets?period=eq.'+period+'&kind=eq.export&select=uploaded_at,row_count');
   return reply({requests:rows,lastUpdate:loads[0]||null});
  }
  if(['refresh-export'].includes(route)&&req.method==='POST'){
   const kind=route==='refresh-export'?'export':'forecast',id=crypto.randomUUID();
   // Reserve before starting the job: concurrent clicks cannot create duplicate runs.
   const reserved=await fetch(BASE+'/rest/v1/lindley_sync_requests',{method:'POST',headers:{apikey:SERVICE,Authorization:'Bearer '+SERVICE,'Content-Type':'application/json'},body:JSON.stringify({id,kind,job_id:SYNC_JOBS[kind],requested_by:user.id})});
   if(reserved.status===409)return reply({ok:true,pending:true});
   if(!reserved.ok)throw new HttpError(500,'No se pudo registrar la actualización.');
   try{
    // Always request history. A running current-month job must not replace this request.
    const run=await databricksApi('/api/2.2/jobs/run-now',{job_id:SYNC_JOBS[kind],idempotency_token:id,job_parameters:{dry_run:'false',dataset:kind,scope:'history'}});
    await backend('/rest/v1/lindley_sync_requests?id=eq.'+id,{method:'PATCH',body:JSON.stringify({run_id:run.run_id})});
   }catch(e){await backend('/rest/v1/lindley_sync_requests?id=eq.'+id,{method:'PATCH',body:JSON.stringify({status:'failed',finished_at:new Date().toISOString()})});throw e}
   return reply({ok:true,pending:true});
  }
  if(route==='import'&&req.method==='POST'){
   const input=await body(req),period=periodOf(input.period),kind=input.kind;
   if(!['universe','export','forecast','routes','mappings'].includes(kind))throw new HttpError(400,'Tipo de base inválido.');
   if(kind==='mappings'){
    try{validateRows(kind,input.rows)}catch(e){throw new HttpError(400,(e as Error).message)}
    const meta=await backend('/rest/v1/lindley_datasets?period=eq.'+period+'&kind=eq.universe&select=path');if(!meta.length)throw new HttpError(400,'Carga primero el universo del mes.');
    const universe=await dataset(meta[0].path),mts=new Set(universe.map((p:any)=>p.mt));
    for(const row of input.rows)if(!mts.has(row.mt))throw new HttpError(400,'MT no existe en el universo del mes: '+row.mt);
    for(const row of input.rows)await ensureAuditor(row);
   }
   return reply(await saveDataset(kind,period,input.rows,String(input.filename||kind+'.json').slice(0,255),user.id));
  }
  if(route==='users'&&req.method==='GET'){
   const profiles=await backend('/rest/v1/lindley_profiles?select=username,name,auditor,role,active,access_code&order=name');
   const metadata=await backend('/rest/v1/lindley_datasets?kind=in.(export,forecast)&order=period.desc&select=path,kind,period');const latest=metadata[0]?.period;const seen=new Set(profiles.map((p:any)=>p.auditor));
   for(const m of metadata.filter((m:any)=>m.period===latest)){for(const row of await dataset(m.path)){const auditor=String(row.user||'').trim().toLowerCase();if(auditor&&!seen.has(auditor)){profiles.push({name:auditor,auditor,role:'auditor',active:false,username:null,access_code:null});seen.add(auditor)}}}
   const mappings=(await currentMappings()).filter((m:any)=>m.active!==false&&!m.removed);return reply(profiles.map((p:any)=>({...p,mt:mappings.find((m:any)=>m.user===p.auditor)?.mt||'',mts:mappings.filter((m:any)=>m.user===p.auditor).map((m:any)=>m.mt),access_code:mappings.find((m:any)=>m.user===p.auditor)?.mt||null})));
  }
  if(route==='users'&&req.method==='POST'){
   const input=await body(req),username=String(input.username||'').trim().toLowerCase(),auditor=String(input.auditor||'').trim().toLowerCase(),name=String(input.name||'').trim();
   if(!/^[a-z0-9._-]{3,50}$/.test(username)||!/^[-a-z0-9._@]{1,100}$/.test(auditor)||!name||name.length>150)throw new HttpError(400,'Completa nombre, usuario (3 a 50 letras, números o puntos) y usuario del export.');
   const existing=await backend('/rest/v1/lindley_profiles?or=(username.eq.'+encodeURIComponent(username)+',auditor.eq.'+encodeURIComponent(auditor)+')&select=id');if(existing.length)throw new HttpError(409,'Ese usuario o auditor ya tiene un acceso.');
   const access_code=await newCode(),password=await codePassword(access_code);
   const account=await backend('/auth/v1/admin/users',{method:'POST',body:JSON.stringify({email:username+'@lindley.portal.invalid',password,email_confirm:true})});
   try{await backend('/rest/v1/lindley_profiles',{method:'POST',body:JSON.stringify({id:account.id,username,name,auditor,role:'auditor',access_code})})}catch(e){console.error('Profile creation failed for auth account',account.id);throw e}return reply({ok:true,access_code});
  }
  throw new HttpError(404,'Acción no encontrada.');
 }catch(e){return reply({error:e instanceof HttpError?e.message:'No se pudo procesar la solicitud.'},e instanceof HttpError?e.status:500)}
});
