ALTER TABLE public.lindley_profiles ADD COLUMN IF NOT EXISTS access_code text;
CREATE UNIQUE INDEX IF NOT EXISTS lindley_profiles_access_code ON public.lindley_profiles(access_code) WHERE access_code IS NOT NULL;
