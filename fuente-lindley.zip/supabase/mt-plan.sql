begin;
alter table public.lindley_datasets drop constraint if exists lindley_datasets_kind_check;
alter table public.lindley_datasets add constraint lindley_datasets_kind_check check(kind in ('universe','export','forecast','routes','mappings'));
commit;
