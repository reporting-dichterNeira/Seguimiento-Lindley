begin;
create table if not exists public.lindley_login_limits(key text primary key, window_start timestamptz not null, failures integer not null default 0);
alter table public.lindley_login_limits enable row level security;
revoke all on public.lindley_login_limits from public,anon,authenticated;
grant select,insert,update,delete on public.lindley_login_limits to service_role;
create or replace function public.lindley_code_limit(p_key text,p_failed boolean default false) returns boolean language plpgsql security invoker set search_path=public as $$
declare w timestamptz := to_timestamp(floor(extract(epoch from now())/900)*900); n integer; global_n integer;
begin
 if p_failed then
  insert into public.lindley_login_limits(key,window_start,failures) values(p_key,w,1)
  on conflict(key) do update set failures=case when lindley_login_limits.window_start=excluded.window_start then lindley_login_limits.failures+1 else 1 end,window_start=excluded.window_start;
  insert into public.lindley_login_limits(key,window_start,failures) values('global',w,1)
  on conflict(key) do update set failures=case when lindley_login_limits.window_start=excluded.window_start then lindley_login_limits.failures+1 else 1 end,window_start=excluded.window_start;
 end if;
 select failures into n from public.lindley_login_limits where key=p_key and window_start=w;
 select failures into global_n from public.lindley_login_limits where key='global' and window_start=w;
 return coalesce(n,0)<5 and coalesce(global_n,0)<30;
end;$$;
revoke all on function public.lindley_code_limit(text,boolean) from public,anon,authenticated;
grant execute on function public.lindley_code_limit(text,boolean) to service_role;
commit;
