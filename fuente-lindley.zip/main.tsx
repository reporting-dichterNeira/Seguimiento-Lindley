import {useState} from 'react';
import {createRoot} from 'react-dom/client';
import Dashboard from './app/dashboard';
import {signIn,signOut,hasSession} from './lib/cloud-api';
import './app/globals.css';import './app/portal.css';
function App(){const [logged,setLogged]=useState(hasSession()),[username,setUsername]=useState(''),[password,setPassword]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setError('');try{await signIn(username,password);setPassword('');setLogged(true)}catch(e){setError((e as Error).message)}finally{setBusy(false)}}
if(logged)return <Dashboard demo onLogout={()=>{void signOut();setLogged(false)}}/>;
return <main className="login"><div className="brand"><span className="dn">d&n</span><div>dichter & neira<strong>Seguimiento Lindley</strong></div></div><section><span className="eyebrow">GESTIÓN DE CAMPO</span><h1>Tu estudio,<br/>al día.</h1><p>Consulta el avance aprobado, el cumplimiento del forecast y la gestión de tiendas Titanes.</p><form className="demo-login" onSubmit={submit}><label>Usuario<input autoComplete="username" required value={username} onChange={e=>setUsername(e.target.value)}/></label><label>Contraseña<input type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)}/></label>{error&&<p role="alert" className="error">{error}</p>}<button className="primary" disabled={busy}>{busy?'Ingresando…':'Ingresar'}</button></form><small>El administrador ve el estudio completo. Cada auditor consulta únicamente su gestión.</small></section></main>}
createRoot(document.getElementById('root')!).render(<App/>);
