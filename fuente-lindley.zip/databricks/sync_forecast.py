# Databricks notebook source
import json
import math
import re
import unicodedata
from collections import Counter, defaultdict
from datetime import date, datetime
from decimal import Decimal
from zoneinfo import ZoneInfo
import requests

dbutils.widgets.dropdown('dry_run', 'true', ['true', 'false'])
dbutils.widgets.dropdown('dataset', 'export', ['export', 'forecast'])
dbutils.widgets.dropdown('scope', 'current', ['current', 'history'])
DRY_RUN = dbutils.widgets.get('dry_run') == 'true'
KIND = dbutils.widgets.get('dataset')
SCOPE = dbutils.widgets.get('scope')
if KIND not in ('export', 'forecast') or SCOPE not in ('current', 'history'):
    raise ValueError('Tipo de base o alcance inválidos.')
PUBLIC_LOGIN_JWT = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp1am5kaGF2b3RpYmZsY3JlZHJ4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODcwNjQ4MTEsImV4cCI6MjEwMjY0MDgxMX0.vljPhiOjqsJJPFSZoEDaSmLeqKS8zWT4CQCnpWFud60'
BASE = 'https://jujndhavotibflcredrx.supabase.co/functions/v1/lindley-api/'
MONTHS = ('ENE','FEB','MAR','ABR','MAY','JUN','JUL','AGO','SEP','OCT','NOV','DIC')
now = datetime.now(ZoneInfo('America/Bogota'))
CURRENT_PERIOD = f'{now.year}-{now.month:02}'

def text(v):
    return '' if v is None else str(v).strip()

def identifier(v):
    if isinstance(v, (int, Decimal)):
        return str(int(v)) if Decimal(v) == Decimal(v).to_integral_value() else str(v)
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return re.sub(r'\.0$', '', text(v))

def iso_date(v):
    if isinstance(v, (datetime, date)):
        return v.isoformat()[:10]
    value = text(v)
    try:
        return datetime.fromisoformat(value.replace('Z', '+00:00')).date().isoformat()
    except ValueError:
        pass
    for fmt in ('%d/%m/%Y', '%d/%m/%Y %H:%M:%S', '%d/%m/%Y %H:%M', '%m/%d/%Y'):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            pass
    raise ValueError('Fecha inválida. Se conservan las bases anteriores.')

def period_of(value):
    value = ''.join(c for c in unicodedata.normalize('NFD', text(value).upper()) if not unicodedata.combining(c))
    year = re.search(r'20\d{2}', value)
    for month, prefix in enumerate(MONTHS, 1):
        if value.startswith(prefix) and year:
            return f'{year.group()}-{month:02}'
    raise ValueError('Ola no tiene un mes y año reconocibles.')

EXPORT_QUERY = """
select
ID_de_audito, ID_de_PDV, Estado, Validador, Fecha_de_validacion,
Fecha_del_audito, fin_del_audito, Hora_del_audito, Hora_fin_del_audito,
canal, segmento, ruta, ciudad, cda_direccion, nombre_usuario, Ola, incidencia
from storeview.slv_sv_ceres_ag_export
where Survey like '%lindley%'
and (ola like '%2026%' or ola like '%2027%')
"""
FORECAST_QUERY = """
select Fecha, Estudio, `Mes Ola`, Forecast, CDA
from storeview.forecast_consalidado_reporting
where fecha > '2026-01-01'
and Estudio like '%Lindley - Auditor%'
"""
QUERY = FORECAST_QUERY if KIND == 'forecast' else EXPORT_QUERY
if KIND == 'export' and SCOPE == 'current':
    if now.year not in (2026, 2027):
        raise ValueError('La consulta del estudio solo está configurada para 2026 y 2027.')
    # Filter the source SQL by Ola, not visit date: visits can belong to another month.
    QUERY += f"and upper(trim(Ola)) like '{MONTHS[now.month-1]}%{now.year}%'"

def normalize_record(r):
    if KIND == 'forecast':
        value = float(r['Forecast'])
        if not math.isfinite(value) or value < 0:
            raise ValueError('Forecast negativo o inválido. No se reemplazaron las bases.')
        return dict(date=iso_date(r['Fecha']), user=text(r['CDA']).lower(),
                    forecast=value, study=text(r['Estudio']), wave=text(r['Mes Ola']))
    return dict(id=identifier(r['ID_de_audito']), code=identifier(r['ID_de_PDV']),
        state=text(r['Estado']), substate='', user=text(r['nombre_usuario']).lower(), auditor='',
        date=iso_date(r['Fecha_del_audito']), updated=text(r['Fecha_de_validacion']),
        route=text(r['ruta']), cda=text(r['cda_direccion']), incidence=text(r['incidencia']),
        wave=text(r['Ola']), titularidad='', validator=text(r['Validador']),
        validatedAt=text(r['Fecha_de_validacion']), finishedAt=text(r['fin_del_audito']),
        startTime=text(r['Hora_del_audito']), endTime=text(r['Hora_fin_del_audito']),
        channel=text(r['canal']), segment=text(r['segmento']), city=text(r['ciudad']))

# Validate the complete result before publishing any period. No LIMIT or truncation.
groups = defaultdict(list)
seen = set()
for source in spark.sql(QUERY).toLocalIterator():
    r = normalize_record(source.asDict())
    period = period_of(r['wave'])
    if not re.fullmatch(r'20\d{2}-\d{2}', period) or not r['user']:
        raise ValueError('Registro incompleto. No se reemplazaron las bases.')
    if KIND == 'export' and (not r['id'] or not r['code']):
        raise ValueError('Export sin ID de auditoría o punto.')
    if KIND == 'export' and SCOPE == 'current' and period != CURRENT_PERIOD:
        raise ValueError('El filtro de la consulta devolvió otra ola. No se reemplazaron las bases.')
    key = (period, r['id']) if KIND == 'export' else (period, r['user'], r['date'])
    if key in seen:
        raise ValueError('Identificador duplicado dentro de una ola. No se reemplazaron las bases.')
    seen.add(key)
    groups[period].append(r)
    if len(groups[period]) > 150000:
        raise ValueError('La ola supera los 150.000 registros permitidos.')
if not groups:
    raise ValueError('La consulta no devolvió datos. Se conservan las bases anteriores.')

payloads = {}
for period, rows in sorted(groups.items()):
    payloads[period] = json.dumps(dict(kind=KIND, period=period, rows=rows), ensure_ascii=False).encode('utf-8')
    if len(payloads[period]) > 40 * 1024 * 1024:
        raise ValueError('La base de una ola supera los 40 MB permitidos.')
summary = dict(dry_run=DRY_RUN, kind=KIND, scope=SCOPE, current_period=CURRENT_PERIOD,
    source='storeview.forecast_consalidado_reporting' if KIND == 'forecast' else 'storeview.slv_sv_ceres_ag_export',
    rows=sum(len(rows) for rows in groups.values()),
    periods={period:dict(rows=len(rows), **({'forecast_total':sum(r['forecast'] for r in rows)} if KIND == 'forecast' else {'states':dict(Counter(r['state'] for r in rows))})) for period, rows in sorted(groups.items())})

if not DRY_RUN:
    from databricks.sdk import WorkspaceClient
    native_auth = WorkspaceClient().config.authenticate()
    headers = {'Content-Type':'application/json', 'Authorization':'Bearer '+PUBLIC_LOGIN_JWT,
        'apikey':'sb_publishable_J2IPbkBfiZ8HSvFWECj4iQ_ALJ6HvEi',
        'x-databricks-token':native_auth['Authorization'].removeprefix('Bearer ')}
    with requests.Session() as session:
        for period, payload in payloads.items():
            response = session.post(BASE+'sync-'+KIND, data=payload, headers=headers, timeout=(30,180))
            if response.status_code != 200:
                try:
                    error = response.json().get('error', 'No se pudo actualizar la base.')
                except ValueError:
                    error = 'No se pudo actualizar la base.'
                raise RuntimeError(f'Supabase rechazó la actualización de {period}: {error}')
            if response.json().get('rows') != len(groups[period]):
                raise RuntimeError('La cantidad guardada no coincide con la consulta.')
            summary['periods'][period]['saved'] = True

# Counts only: no records or credentials in the notebook output.
dbutils.notebook.exit(json.dumps(summary, ensure_ascii=False))
