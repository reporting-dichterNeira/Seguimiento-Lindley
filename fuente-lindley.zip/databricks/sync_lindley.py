# Databricks notebook source
import json
import re
import unicodedata
from collections import Counter, defaultdict
from datetime import date, datetime
from decimal import Decimal
import requests

dbutils.widgets.dropdown('dry_run', 'true', ['true', 'false'])
DRY_RUN = dbutils.widgets.get('dry_run') == 'true'
dbutils.widgets.dropdown('only_requested', 'false', ['true', 'false'])
ONLY_REQUESTED = dbutils.widgets.get('only_requested') == 'true'
PUBLIC_LOGIN_JWT = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp1am5kaGF2b3RpYmZsY3JlZHJ4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODcwNjQ4MTEsImV4cCI6MjEwMjY0MDgxMX0.vljPhiOjqsJJPFSZoEDaSmLeqKS8zWT4CQCnpWFud60'
headers = None
requests_ids = []
if not DRY_RUN:
    from databricks.sdk import WorkspaceClient
    native_auth = WorkspaceClient().config.authenticate()
    headers = {'Content-Type':'application/json', 'Authorization':'Bearer '+PUBLIC_LOGIN_JWT,
        'apikey':'sb_publishable_J2IPbkBfiZ8HSvFWECj4iQ_ALJ6HvEi',
        'x-databricks-token':native_auth['Authorization'].removeprefix('Bearer ')}
    pending = requests.post('https://jujndhavotibflcredrx.supabase.co/functions/v1/lindley-api/sync-requests', json={}, headers=headers, timeout=(20,40))
    if pending.status_code != 200:
        raise RuntimeError('No se pudo verificar la identidad o consultar las solicitudes de actualización.')
    requests_ids = [r['id'] for r in pending.json()]
    if ONLY_REQUESTED and not requests_ids:
        dbutils.notebook.exit(json.dumps({'skipped':True,'reason':'No hay solicitudes pendientes.'}))
try:
    QUERY = '''
    select
    ID_de_audito, ID_de_PDV, Estado, Validador, Fecha_de_validacion,
    Fecha_del_audito, fin_del_audito, Hora_del_audito, Hora_fin_del_audito,
    canal, segmento, ruta, ciudad, cda_direccion, nombre_usuario, Ola, incidencia
    from storeview.slv_sv_ceres_ag_export
    where Survey like '%lindley%'
    and (ola like '%2026%' or ola like '%2027%')
    '''
    
    def text(v):
        return '' if v is None else str(v).strip()
    
    def identifier(v):
        if isinstance(v, (int, Decimal)):
            return str(int(v)) if Decimal(v) == Decimal(v).to_integral_value() else str(v)
        if isinstance(v, float) and v.is_integer():
            return str(int(v))
        return re.sub(r'\.0$', '', text(v))
    
    def iso_date(v):
        if isinstance(v, (datetime, date)):
            return v.isoformat()[:10]
        value = text(v)
        try:
            return datetime.fromisoformat(value.replace('Z', '+00:00')).date().isoformat()
        except ValueError:
            pass
        for fmt in ('%d/%m/%Y', '%d/%m/%Y %H:%M:%S', '%d/%m/%Y %H:%M', '%m/%d/%Y'):
            try:
                return datetime.strptime(value, fmt).date().isoformat()
            except ValueError:
                pass
        raise ValueError('Fecha_del_audito no válida. La sincronización no reemplazó las bases.')
    
    def period_of(value):
        value = ''.join(c for c in unicodedata.normalize('NFD', text(value).upper()) if not unicodedata.combining(c))
        year = re.search(r'20\d{2}', value)
        for month, prefix in enumerate(('ENE','FEB','MAR','ABR','MAY','JUN','JUL','AGO','SEP','OCT','NOV','DIC'), 1):
            if value.startswith(prefix) and year:
                return f'{year.group()}-{month:02}'
        raise ValueError('Ola no tiene un mes y año reconocibles. La sincronización no reemplazó las bases.')
    
    def normalize_record(r):
        return dict(id=identifier(r['ID_de_audito']), code=identifier(r['ID_de_PDV']),
            state=text(r['Estado']), substate='', user=text(r['nombre_usuario']).lower(), auditor='',
            date=iso_date(r['Fecha_del_audito']), updated=text(r['Fecha_de_validacion']),
            route=text(r['ruta']), cda=text(r['cda_direccion']), incidence=text(r['incidencia']),
            wave=text(r['Ola']), titularidad='', validator=text(r['Validador']),
            validatedAt=text(r['Fecha_de_validacion']), finishedAt=text(r['fin_del_audito']),
            startTime=text(r['Hora_del_audito']), endTime=text(r['Hora_fin_del_audito']),
            channel=text(r['canal']), segment=text(r['segmento']), city=text(r['ciudad']))
    
    # Validate the complete query before publishing any month. No truncation or LIMIT.
    groups = defaultdict(list)
    seen = set()
    for source in spark.sql(QUERY).toLocalIterator():
        r = normalize_record(source.asDict())
        period = period_of(r['wave'])
        if not re.fullmatch(r'202[67]-\d{2}', period) or not r['id'] or not r['code'] or not r['user']:
            raise ValueError('Registro incompleto o de otra ola. No se reemplazaron las bases.')
        key = (period, r['id'])
        if key in seen:
            raise ValueError('ID_de_audito duplicado dentro de una ola. No se reemplazaron las bases.')
        seen.add(key)
        groups[period].append(r)
        if len(groups[period]) > 150000:
            raise ValueError('La ola supera los 150.000 registros permitidos.')
    if not groups:
        raise ValueError('La consulta no devolvió datos. Se conservan las bases anteriores.')
    
    payloads = {}
    for period, rows in sorted(groups.items()):
        payloads[period] = json.dumps(dict(kind='export', period=period, rows=rows), ensure_ascii=False).encode('utf-8')
        if len(payloads[period]) > 40 * 1024 * 1024:
            raise ValueError('El export de una ola supera los 40 MB permitidos.')
    
    summary = dict(dry_run=DRY_RUN, source='storeview.slv_sv_ceres_ag_export',
        rows=sum(len(rows) for rows in groups.values()),
        periods={period:dict(rows=len(rows), states=dict(Counter(r['state'] for r in rows))) for period, rows in sorted(groups.items())})
    if not DRY_RUN:
        session = requests.Session()
        for period, payload in payloads.items():
            response = session.post('https://jujndhavotibflcredrx.supabase.co/functions/v1/lindley-api/sync-export',
                data=payload, headers=headers, timeout=(30, 180))
            if response.status_code != 200:
                try:
                    error = response.json().get('error', 'No se pudo actualizar el export.')
                except ValueError:
                    error = 'No se pudo actualizar el export.'
                raise RuntimeError(f'Supabase rechazó la actualización de {period}: {error}')
            result = response.json()
            if result.get('rows') != len(groups[period]):
                raise RuntimeError('La cantidad guardada no coincide con la consulta.')
            summary['periods'][period]['saved'] = True
        if requests_ids:
            completed = session.post('https://jujndhavotibflcredrx.supabase.co/functions/v1/lindley-api/sync-complete', json={'ids':requests_ids}, headers=headers, timeout=(20,40))
            if completed.status_code != 200:
                raise RuntimeError('Los exports se guardaron, pero no se pudo confirmar la solicitud.')
        session.close()
    
    
except Exception:
    if requests_ids and headers:
        try:
            requests.post('https://jujndhavotibflcredrx.supabase.co/functions/v1/lindley-api/sync-complete', json={'ids':requests_ids,'failed':True}, headers=headers, timeout=(20,40))
        except Exception:
            pass
    raise

# Only counts and states reach the run log; codes, credentials and PDV records do not.
dbutils.notebook.exit(json.dumps(summary, ensure_ascii=False))
