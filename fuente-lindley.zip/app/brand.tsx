import logo from '../assets/logo-dichter-neira.png';
export default function Brand(){return <div className="brand"><img className="brand-logo" src={logo} alt="dichter & neira" width={270} height={86}/><strong className="brand-title">Seguimiento Lindley</strong></div>;}
