import {useState} from 'react';
import MetricTable from './metric-table';
import {auditorRoster,auditorIdentity,matchesAssignment} from '../lib/auditor-display.mjs';
export default function AuditorMetrics({rows,mappings,routes=[]}:{rows:any[];mappings:any[];routes?:any[]}){
 const [assignment,setAssignment]=useState('all'),[search,setSearch]=useState('');
 const {byUser}=auditorRoster(mappings);
 const visible=rows.filter(row=>{
  const person=byUser.get(row.key),mt=row.key.startsWith('mt:')?row.key.slice(3):'';
  return matchesAssignment(person,assignment)&&[row.key,mt,...(person?.mts||[])].some(value=>value.toLowerCase().includes(search.trim().toLowerCase()));
 }).sort((a,b)=>auditorIdentity(a).localeCompare(auditorIdentity(b),'es'));
 return <section className="panel"><h2>Gestión por auditor</h2><div className="auditor-month-filters"><label>Buscar usuario o MT<input value={search} onChange={e=>setSearch(e.target.value)} placeholder="pe.cp.usuario o LIME101"/></label><label>Asignación de MT<select value={assignment} onChange={e=>setAssignment(e.target.value)}><option value="all">Todas las asignaciones</option><option value="shared">MT compartido</option><option value="multiple">Usuario con varios MT</option></select></label></div>
 <p className="method">{visible.length} usuarios o MT. Los MT compartidos reparten la cuota y el forecast entre sus usuarios activos.</p><MetricTable rows={visible} label="Usuario / MT" mappings={mappings} routes={routes}/>{!visible.length&&<p role="status">No hay resultados con esos filtros.</p>}
 <p className="method">Se muestra el usuario del export. Cuando aún no tiene equivalencia, se muestra el MT del universo.</p></section>;
}
