import {fmt,pct} from './administration';
type Status={state:string;audits:number};
const colors:Record<string,string>={'Aprobada':'#16815c','Alerta':'#bc7410','Cancelada':'#ba365d','En Proceso':'#657594','Incidencia':'#874cb4','Requiere Aprobación':'#0d5cab','Exenta por Validación Smart':'#00899e','Cancelación Automática':'#9d445d','Exenta':'#438671'};
export default function ExportStatusChart({rows}:{rows:Status[]}){
 const total=rows.reduce((n,row)=>n+row.audits,0),max=Math.max(1,...rows.map(row=>row.audits));
 return <section className="panel"><div className="panel-title"><h2>Estados del export</h2><span className="status-total"><strong>{fmt(total)}</strong> auditorías</span></div>
  <p>Registros de ID_de_audito por estado. En revisión reúne Alerta, En Proceso y Requiere Aprobación. El avance cuenta puntos efectivos una sola vez. Smart y cancelación automática se identifican con SubStatus.</p>
  {total>0?<ul className="status-chart" aria-label="Auditorías por estado">{rows.map(row=><li key={row.state}><span className="status-name">{row.state}</span><div className="status-track" aria-hidden="true"><div className="status-bar" style={{width:(row.audits/max*100)+'%',background:colors[row.state]||'#657594'}}/></div><span className="status-value"><strong>{fmt(row.audits)}</strong><small>{pct(row.audits/total)} del total</small></span></li>)}</ul>:<p role="status">No hay auditorías para el mes y corte seleccionados.</p>}
  <p className="method">Si un punto tiene varias auditorías, una auditoría con estado efectivo lo incluye en el avance una sola vez; cada auditoría se conserva en esta gráfica.</p>
 </section>;
}
