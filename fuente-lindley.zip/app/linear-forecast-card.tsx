'use client';
import {fmt,pct} from './administration';
type LinearForecast={forecast:number;effective:number;compliance:number|null;fullForecast:number;cutoff:string};
export default function LinearForecastCard({value}:{value:LinearForecast|null}){
 return <article className="linear-forecast-card" aria-label="% de avance vs forecast lineal"><span>% de avance vs forecast lineal</span><strong>{pct(value?.compliance)}</strong><small>{value?`${fmt(value.effective)} efectivas / ${fmt(value.forecast)} meta lineal al corte`:'Sin forecast lineal cargado para este mes.'}</small>{value&&<small>{value.forecast?'Efectivas acumuladas ÷ meta lineal acumulada.':'Aún no hay meta lineal programada al corte.'}</small>}</article>;
}
