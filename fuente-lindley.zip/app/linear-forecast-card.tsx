'use client';
import {fmt,pct} from './administration';
import GapIndicator from './gap-indicator';
type LinearForecast={forecast:number;effective:number;compliance:number|null;fullForecast:number;cutoff:string};
export default function LinearForecastCard({value}:{value:LinearForecast|null}){
 return <article className="linear-forecast-card" aria-label="% de avance vs forecast lineal"><span>% de avance vs forecast lineal</span><strong>{pct(value?.compliance)}</strong><small>{value?`${fmt(value.effective)} efectivas / ${fmt(value.forecast)} meta lineal`:'Sin forecast lineal cargado para este mes.'}</small>{value&&<small><GapIndicator gap={value.forecast-value.effective} forecast={value.forecast}/></small>}</article>;
}
