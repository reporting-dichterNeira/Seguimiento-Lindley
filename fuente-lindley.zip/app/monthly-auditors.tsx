import {useState} from 'react';
import {Table,TableHeader,TableRow,TableHead,TableBody,TableCell} from '@/components/ui/table';
import {toast} from 'sonner';
import {cloudApi} from '../lib/cloud-api';
import {auditorRoster,matchesAssignment} from '../lib/auditor-display.mjs';

type Mapping={mt:string;user:string;name?:string;active?:boolean;removed?:boolean};
type Props={rows:Mapping[];period:string;version:string;refresh:()=>void};
export default function MonthlyAuditors({rows,period,version,refresh}:Props){
 const [name,setName]=useState(''),[auditor,setAuditor]=useState(''),[mts,setMts]=useState('');
 const [search,setSearch]=useState(''),[assignment,setAssignment]=useState('all'),[filter,setFilter]=useState('all'),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const [removing,setRemoving]=useState<string|null>(null);
 const {byUser:grouped,byMT,people}=auditorRoster(rows);
 const sharedCount=[...byMT.values()].filter(users=>users.size>1).length;
 const multipleCount=people.filter(p=>p.active&&p.mts.length>1).length;
 const visible=people.filter(p=>(filter==='removed'?p.removed:!p.removed&&(filter==='all'||filter==='active'&&p.active||filter==='inactive'&&!p.active))&&matchesAssignment(p,assignment)&&[p.user,...p.mts].some(v=>v.toLowerCase().includes(search.trim().toLowerCase())));
 async function change(action:string,user:string,extra:Record<string,unknown>={}){
  setBusy(true);setError('');
  try{await cloudApi('/api/monthly-auditors',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({period,version,action,auditor:user,...extra})});setRemoving(null);toast.success(action==='remove'?'Auditor retirado del mes. Puedes restaurarlo en Retirados.':action==='add'?'Auditor añadido y activo en el mes.':'Estado del mes actualizado.');refresh();return true}
  catch(e){setError((e as Error).message);return false}
  finally{setBusy(false)}
 }
 async function add(e:React.FormEvent){e.preventDefault();if(await change('add',auditor,{name,mts})){setName('');setAuditor('');setMts('')}}
 async function copy(value:string){try{await navigator.clipboard.writeText(value);toast.success('MT copiado.')}catch{setError('No se pudo copiar. Selecciona el MT y cópialo manualmente.')}}
 return <section className="panel monthly-auditors"><div className="panel-title"><h2>Equivalencias y auditores del mes</h2><span>{period}</span></div>
  <p>{people.filter(p=>p.active).length} auditores activos · {new Set(rows.filter(r=>r.active!==false&&!r.removed).map(r=>r.mt)).size} MT activos. El estado se guarda únicamente para el mes seleccionado.</p>
  <p>Un auditor puede tener varios MT. Un MT compartido reparte la cuota y el forecast por igual entre sus auditores activos. El avance corresponde a las aprobadas de cada usuario.</p>
  <form className="user-form" onSubmit={add}>
   <label>Nombre del auditor<input required maxLength={150} value={name} onChange={e=>setName(e.target.value)} placeholder="Nombre y apellido" disabled={busy}/></label>
   <label>Usuario del export<input required maxLength={100} value={auditor} onChange={e=>setAuditor(e.target.value.toLowerCase())} placeholder="pe.cp.usuario" disabled={busy}/></label>
   <label>MT / códigos de acceso<input required value={mts} onChange={e=>setMts(e.target.value.toUpperCase())} placeholder="LIME101, HHOE101" disabled={busy}/></label>
   <button className="primary" disabled={busy}>{busy?'Guardando…':'Añadir auditor al mes'}</button>
  </form>
  <small>Si el usuario ya existe, se conserva su cuenta y se añaden sus MT a este mes. Si es nuevo, se habilita su acceso. Puedes añadirlo antes de actualizar el universo.</small>
  <div className="auditor-month-filters"><label>Buscar usuario o MT<input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Usuario o MT"/></label><label>Estado en el mes<select value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">Todos los auditores del mes</option><option value="active">Activos en el mes</option><option value="inactive">Inactivos en el mes</option><option value="removed">Retirados del mes</option></select></label><label>Asignación de MT<select value={assignment} onChange={e=>setAssignment(e.target.value)}><option value="all">Todas las asignaciones</option><option value="shared">MT compartido ({sharedCount} MT)</option><option value="multiple">Usuario con varios MT ({multipleCount} usuarios activos)</option></select></label></div>
  {error&&<p className="error" role="alert">{error}</p>}
  {removing&&<div className="auditor-remove-confirm" role="alert"><p>Retirar a {grouped.get(removing)?.user} de {period} deshabilita sus MT para este mes. Su historial se conserva y puedes restaurarlo.</p><button className="secondary" disabled={busy} onClick={()=>setRemoving(null)}>Cancelar</button><button className="primary" disabled={busy} onClick={()=>void change('remove',removing)}>Confirmar retiro del mes</button></div>}
  <Table><TableHeader><TableRow>{['Usuario del export','MT / código de acceso','Activo en el mes','Acciones'].map(h=><TableHead key={h}>{h}</TableHead>)}</TableRow></TableHeader><TableBody>{visible.map(p=><TableRow key={p.user}><TableCell><span className="auditor-identity">{p.user}</span>{p.mts.length>1&&<span className="assignment-badge multiple">{p.mts.length} MT</span>}</TableCell><TableCell>{p.mts.map((mt:string)=><div key={mt}><code className="access-code">{mt}</code> <button type="button" className="secondary" aria-label={'Copiar '+mt+' de '+p.user} onClick={()=>void copy(mt)}>Copiar</button>{p.sharedMTs.includes(mt)&&<details className="shared-mt-detail"><summary><span className="assignment-badge">Compartido · {byMT.get(mt)?.size} usuarios</span></summary><p>También asignado a:</p><ul>{[...(byMT.get(mt)||[])].filter(user=>user!==p.user).map(user=><li key={user}>{user}</li>)}</ul></details>}</div>)}</TableCell><TableCell>{p.removed?'Retirado':<label><input type="checkbox" aria-label={'Activo en '+period+': '+p.user} checked={p.active} disabled={busy} onChange={e=>void change('status',p.user,{active:e.target.checked})}/> {p.active?'Activo':'Inactivo'}</label>}</TableCell><TableCell>{p.removed?<button className="secondary" disabled={busy} onClick={()=>void change('restore',p.user)}>Restaurar al mes</button>:<button className="secondary" disabled={busy} onClick={()=>setRemoving(p.user)}>Eliminar del mes</button>}</TableCell></TableRow>)}</TableBody></Table>
  {!visible.length&&<p role="status">No hay auditores con ese filtro.</p>}
  <small>Marcar inactivo o retirar no borra las auditorías realizadas ni cambia otros meses. Los MT sin auditores activos quedan pendientes de homologación.</small>
 </section>;
}
