import {useState} from 'react';
import {Table,TableHeader,TableRow,TableHead,TableBody,TableCell} from '@/components/ui/table';
import {toast} from 'sonner';
import {cloudApi} from '../lib/cloud-api';

type Mapping={mt:string;user:string;name?:string;active?:boolean;removed?:boolean};
type Props={rows:Mapping[];period:string;version:string;refresh:()=>void};
export default function MonthlyAuditors({rows,period,version,refresh}:Props){
 const [name,setName]=useState(''),[auditor,setAuditor]=useState(''),[mts,setMts]=useState('');
 const [search,setSearch]=useState(''),[filter,setFilter]=useState('all'),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const [removing,setRemoving]=useState<string|null>(null);
 const grouped=new Map<string,{user:string;name:string;mts:string[];active:boolean;removed:boolean}>();
 for(const row of rows){let person=grouped.get(row.user);if(!person){person={user:row.user,name:row.name||row.user,mts:[],active:false,removed:true};grouped.set(row.user,person)}person.mts.push(row.mt);person.active ||= row.active!==false&&!row.removed;person.removed &&= !!row.removed;}
 const people=[...grouped.values()].sort((a,b)=>a.name.localeCompare(b.name,'es'));
 const visible=people.filter(p=>(filter==='removed'?p.removed:!p.removed&&(filter==='all'||filter==='active'&&p.active||filter==='inactive'&&!p.active))&&[p.name,p.user,...p.mts].some(v=>v.toLowerCase().includes(search.trim().toLowerCase())));
 async function change(action:string,user:string,extra:Record<string,unknown>={}){
  setBusy(true);setError('');
  try{await cloudApi('/api/monthly-auditors',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({period,version,action,auditor:user,...extra})});setRemoving(null);toast.success(action==='remove'?'Auditor retirado del mes. Puedes restaurarlo en Retirados.':action==='add'?'Auditor añadido y activo en el mes.':'Estado del mes actualizado.');refresh();return true}
  catch(e){setError((e as Error).message);return false}
  finally{setBusy(false)}
 }
 async function add(e:React.FormEvent){e.preventDefault();if(await change('add',auditor,{name,mts})){setName('');setAuditor('');setMts('')}}
 async function copy(value:string){try{await navigator.clipboard.writeText(value);toast.success('MT copiado.')}catch{setError('No se pudo copiar. Selecciona el MT y cópialo manualmente.')}}
 return <section className="panel monthly-auditors"><div className="panel-title"><h2>Equivalencias y auditores del mes</h2><span>{period}</span></div>
  <p>{people.filter(p=>p.active).length} auditores activos · {new Set(rows.filter(r=>r.active!==false&&!r.removed).map(r=>r.mt)).size} MT activos. El estado se guarda únicamente para el mes seleccionado.</p>
  <p>Un auditor puede tener varios MT. Un MT compartido reparte la cuota y el forecast por igual entre sus auditores activos. El avance corresponde a las aprobadas de cada usuario.</p>
  <form className="user-form" onSubmit={add}>
   <label>Nombre del auditor<input required maxLength={150} value={name} onChange={e=>setName(e.target.value)} placeholder="Nombre y apellido" disabled={busy}/></label>
   <label>Usuario del export<input required maxLength={100} value={auditor} onChange={e=>setAuditor(e.target.value.toLowerCase())} placeholder="pe.cp.usuario" disabled={busy}/></label>
   <label>MT / códigos de acceso<input required value={mts} onChange={e=>setMts(e.target.value.toUpperCase())} placeholder="LIME101, HHOE101" disabled={busy}/></label>
   <button className="primary" disabled={busy}>{busy?'Guardando…':'Añadir auditor al mes'}</button>
  </form>
  <small>Si el usuario ya existe, se conserva su cuenta y se añaden sus MT a este mes. Si es nuevo, se habilita su acceso. Puedes añadirlo antes de actualizar el universo.</small>
  <div className="auditor-month-filters"><label>Buscar auditor o MT<input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Nombre, usuario o MT"/></label><label>Estado en el mes<select value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">Todos los auditores del mes</option><option value="active">Activos en el mes</option><option value="inactive">Inactivos en el mes</option><option value="removed">Retirados del mes</option></select></label></div>
  {error&&<p className="error" role="alert">{error}</p>}
  {removing&&<div className="auditor-remove-confirm" role="alert"><p>Retirar a {grouped.get(removing)?.name} de {period} deshabilita sus MT para este mes. Su historial se conserva y puedes restaurarlo.</p><button className="secondary" disabled={busy} onClick={()=>setRemoving(null)}>Cancelar</button><button className="primary" disabled={busy} onClick={()=>void change('remove',removing)}>Confirmar retiro del mes</button></div>}
  <Table><TableHeader><TableRow>{['Nombre','Usuario del export','MT / código de acceso','Activo en el mes','Acciones'].map(h=><TableHead key={h}>{h}</TableHead>)}</TableRow></TableHeader><TableBody>{visible.map(p=><TableRow key={p.user}><TableCell>{p.name}</TableCell><TableCell>{p.user}</TableCell><TableCell>{p.mts.map(mt=><div key={mt}><code className="access-code">{mt}</code> <button type="button" className="secondary" aria-label={'Copiar '+mt+' de '+p.name} onClick={()=>void copy(mt)}>Copiar</button></div>)}</TableCell><TableCell>{p.removed?'Retirado':<label><input type="checkbox" aria-label={'Activo en '+period+': '+p.name} checked={p.active} disabled={busy} onChange={e=>void change('status',p.user,{active:e.target.checked})}/> {p.active?'Activo':'Inactivo'}</label>}</TableCell><TableCell>{p.removed?<button className="secondary" disabled={busy} onClick={()=>void change('restore',p.user)}>Restaurar al mes</button>:<button className="secondary" disabled={busy} onClick={()=>setRemoving(p.user)}>Eliminar del mes</button>}</TableCell></TableRow>)}</TableBody></Table>
  {!visible.length&&<p role="status">No hay auditores con ese filtro.</p>}
  <small>Marcar inactivo o retirar no borra las auditorías realizadas ni cambia otros meses. Los MT sin auditores activos quedan pendientes de homologación.</small>
 </section>;
}
