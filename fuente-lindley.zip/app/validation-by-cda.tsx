'use client';
import {Table,TableHeader,TableRow,TableHead,TableBody,TableCell} from '@/components/ui/table';
import {fmt,pct} from './administration';
import {EXPORT_STATUSES,EFFECTIVE_STATUSES} from '../lib/study-engine.mjs';
const states:string[]=EXPORT_STATUSES;
const effectiveStates=new Set<string>(EFFECTIVE_STATUSES);
export default function ValidationByCda({rows,period}:{rows:any[];period:string}){
 const visibleStates=states.filter(state=>state!=='Exenta por Validación Smart'||rows.some(r=>(r.validation?.statuses?.[state]||0)>0));
 return <><p className="validation-note"><span className="validation-note-key" aria-hidden="true"/><span><strong>Estados resaltados: cuentan para el avance.</strong> Se consideran {EFFECTIVE_STATUSES.join(', ')}. El avance cuenta cada punto del universo una sola vez, aunque tenga varias auditorías.</span></p><p className="method">La tabla cuenta auditorías por estado. El porcentaje pendiente es Requiere Aprobación ÷ total de auditorías.</p><Table className="metrics-table validation-cda" exportName={'Validación por CDA '+period}><TableHeader><TableRow><TableHead className="sticky-name">CDA</TableHead>{['Total auditorías',...visibleStates,'Otros estados','% pendiente por validar'].map(h=><TableHead key={h} className={effectiveStates.has(h)?"effective-state-head":undefined}>{h}</TableHead>)}</TableRow></TableHeader><TableBody>{rows.map((r:any)=>{const v=r.validation||{total:0,statuses:{}};const other=Object.entries(v.statuses).reduce((sum:number,[state,count]:any)=>sum+(states.includes(state)?0:Number(count)),0);return <TableRow key={r.key}><TableCell className="sticky-name">{r.name}</TableCell><TableCell>{fmt(v.total)}</TableCell>{visibleStates.map(state=><TableCell key={state}>{fmt(v.statuses[state]||0)}</TableCell>)}<TableCell>{fmt(other)}</TableCell><TableCell>{v.total?pct((v.statuses['Requiere Aprobación']||0)/v.total):'—'}</TableCell></TableRow>})}</TableBody></Table></>;
}
