'use client';
import {useMemo,useState} from 'react';
import {toast} from 'sonner';
import {Table,TableHeader,TableRow,TableHead,TableBody,TableCell} from '@/components/ui/table';
import {resolveFieldCalendar} from '@/lib/study-engine.mjs';
import {cloudApi} from '@/lib/cloud-api';

type Mode='auto'|'field'|'previous';
type CalendarRow={date:string;audits:number;mode:Mode;isFieldDay:boolean;fieldDay:number|null;productionDate:string|null};
const choices:Record<Mode,string>={auto:'Automático',field:'Día de campo',previous:'Sumar al anterior'};
const dateLabel=(date:string)=>new Intl.DateTimeFormat('es-PE',{day:'2-digit',month:'2-digit',year:'numeric',timeZone:'UTC'}).format(new Date(date+'T12:00:00Z'));
export default function FieldCalendar({rows,period,version,refresh}:{rows:CalendarRow[];period:string;version:string;refresh:()=>void}){
 const [modes,setModes]=useState<Record<string,Mode>>(()=>Object.fromEntries(rows.map(r=>[r.date,r.mode])));
 const [showAll,setShowAll]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const edits=rows.map(r=>({date:r.date,mode:modes[r.date]||'auto'}));
 const preview=useMemo(()=>resolveFieldCalendar({period,auditCounts:rows,calendar:rows.map(r=>({date:r.date,mode:modes[r.date]||'auto'}))}),[rows,modes,period]);
 const dirty=rows.some(r=>(modes[r.date]||'auto')!==r.mode);
 const visible:CalendarRow[]=preview.rows.filter((r:CalendarRow)=>showAll||r.audits>0||r.mode!=='auto');
 const assignment=(r:CalendarRow)=>!r.audits?'Sin auditorías':r.fieldDay?`Día ${r.fieldDay} · ${dateLabel(r.productionDate!)}`:'Sin día anterior; conserva su fecha';
 async function save(){setBusy(true);setError('');try{
  await cloudApi('/api/field-calendar',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({period,version,rows:edits})});
  toast.success('Calendario guardado. Se recalcularon los días de campo y el forecast.');refresh();
 }catch(e){setError((e as Error).message)}finally{setBusy(false)}}
 return <section className="panel field-calendar"><h2>Calendario de días de campo</h2>
  <p>Automático: una fecha cuenta como día de campo desde 3 auditorías en toda la ola. Si tiene solo 1 o 2, su productividad se suma al día de campo anterior.</p>
  <p>Para corregir una fecha, elige <strong>Día de campo</strong> para incluirla o <strong>Sumar al anterior</strong> para excluirla. Los días se renumeran en orden y el forecast se ajusta. El export conserva las fechas originales.</p>
  <div className="calendar-toolbar"><label><input type="checkbox" checked={showAll} onChange={e=>setShowAll(e.target.checked)}/> Mostrar todas las fechas del mes</label><span>{preview.fieldDates.length} días de campo identificados</span></div>
  <Table exportName={'Calendario de campo '+period} exportData={()=>[['Fecha','Auditorías de la ola','Tratamiento','Día de campo','Productividad asignada'],...visible.map(r=>[r.date,r.audits,choices[r.mode],r.isFieldDay?r.fieldDay:'No cuenta',assignment(r)])]}>
   <TableHeader><TableRow>{['Fecha','Auditorías de la ola','Tratamiento','Día de campo','Productividad asignada'].map(h=><TableHead key={h}>{h}</TableHead>)}</TableRow></TableHeader>
   <TableBody>{visible.map(r=><TableRow key={r.date}><TableCell>{dateLabel(r.date)}</TableCell><TableCell>{r.audits}</TableCell><TableCell><select disabled={busy} aria-label={'Tratamiento '+r.date} value={r.mode} onChange={e=>{setModes(old=>({...old,[r.date]:e.target.value as Mode}));setError('')}}>{Object.entries(choices).map(([value,label])=><option key={value} value={value}>{label}</option>)}</select></TableCell><TableCell>{r.isFieldDay?<strong>Día {r.fieldDay}</strong>:'No cuenta'}</TableCell><TableCell>{assignment(r)}</TableCell></TableRow>)}</TableBody>
  </Table>
  {!visible.length&&<p>No hay auditorías ni ajustes. Activa «Mostrar todas las fechas del mes» para planificar días manualmente.</p>}
  {preview.rows.some((r:CalendarRow)=>r.audits>0&&!r.fieldDay)&&<p className="notice">Hay auditorías anteriores al primer día de campo válido. Conservan su productividad en su fecha original, sin crear un día de campo. Puedes incluir esa fecha manualmente.</p>}
  <div className="actions"><button className="primary" disabled={!dirty||busy} onClick={()=>void save()}>{busy?'Guardando…':'Guardar días de campo'}</button><button className="secondary" disabled={busy} onClick={()=>{setModes(Object.fromEntries(rows.map(r=>[r.date,'auto'])));setError('')}}>Restablecer automático</button>{dirty&&<button className="secondary" disabled={busy} onClick={()=>{setModes(Object.fromEntries(rows.map(r=>[r.date,r.mode])));setError('')}}>Descartar cambios</button>}</div>
  <p className="method" role="status">{dirty?'Cambios sin guardar. Guarda para aplicarlos al portal.':'El calendario guardado se aplica al administrador y a todos los auditores del mes.'} Las auditorías se cuentan por ID, incluyendo todos sus estados. La fecha de corte sigue usando la fecha original de la visita.</p>
  {error&&<p className="error" role="alert">{error}</p>}
 </section>;
}
