'use client';
import {gapStatus} from '@/lib/gap-status.mjs';
import {fmt} from './administration';
const descriptions={green:'Verde: meta cumplida o superada.',yellow:'Amarillo: falta hasta el 10 % de la meta.',red:'Rojo: avance por debajo de la meta.',unknown:'Sin meta disponible.'};
export default function GapIndicator({gap,forecast,label=true}:{gap:number|null|undefined;forecast:number|null|undefined;label?:boolean}){
 const status=gapStatus(gap,forecast)==='unknown'?'unknown':Number(gap)>0?'red':'green';
 const display=gap==null?'—':gap<0?'+'+fmt(-gap):fmt(-gap);
 return <span className={'gap-indicator gap-'+status} title={descriptions[status]} aria-label={'GAP '+(status==='unknown'?'sin dato':display)+'. '+descriptions[status]}><i className="gap-dot" aria-hidden="true"/>{label?'GAP ':''}{status==='unknown'?'—':display}</span>;
}
