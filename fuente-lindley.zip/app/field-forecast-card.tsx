'use client';
import {fmt,pct} from './administration';
import GapIndicator from './gap-indicator';
type FieldForecast={forecast:number;effective:number;compliance:number|null;gap:number;fullForecast:number;cutoff:string};
export default function FieldForecastCard({value}:{value:FieldForecast}){
 return <article className="field-forecast-card" aria-label="% de avance vs forecast de campo"><span>% de avance vs forecast de campo</span><strong>{pct(value.compliance)}</strong><small>{fmt(value.effective)} efectivas / {fmt(value.forecast)} meta de campo al corte</small><small><GapIndicator gap={value.gap} forecast={value.forecast}/></small></article>;
}
