const base='https://jujndhavotibflcredrx.supabase.co';
const key=import.meta.env.VITE_SUPABASE_ANON_KEY||'';
const storageKey='lindley-auth-session';
const load=()=>{try{return JSON.parse(sessionStorage.getItem(storageKey)||'null')}catch{return null}};
export const hasSession=()=>!!load()?.access_token;
async function login(route:string,input:unknown){const r=await fetch(base+'/functions/v1/lindley-api/'+route,{method:'POST',headers:{apikey:key,Authorization:'Bearer '+import.meta.env.VITE_SUPABASE_LOGIN_JWT,'Content-Type':'application/json'},body:JSON.stringify(input)});const data=await r.json();if(!r.ok)throw new Error(data.error||'No se pudo ingresar.');if(data.access_token)sessionStorage.setItem(storageKey,JSON.stringify(data));return data;}
export const signIn=(username:string,password:string)=>login('admin-login',{username,password});
export const signInCode=(code:string,auditor?:string)=>login('code-login',{code,auditor});
export async function signOut(){const session=load();sessionStorage.removeItem(storageKey);if(session)await fetch(base+'/auth/v1/logout',{method:'POST',headers:{apikey:key,Authorization:'Bearer '+session.access_token}});}
async function token(){let s=load();if(!s)throw new Error('La sesión expiró. Ingresa de nuevo.');if(s.expires_at<Date.now()/1000+60){const r=await fetch(base+'/auth/v1/token?grant_type=refresh_token',{method:'POST',headers:{apikey:key,'Content-Type':'application/json'},body:JSON.stringify({refresh_token:s.refresh_token})});if(!r.ok){sessionStorage.removeItem(storageKey);throw new Error('La sesión expiró. Ingresa de nuevo.')}s=await r.json();sessionStorage.setItem(storageKey,JSON.stringify(s));}return s.access_token;}
export async function cloudApi(url:string,options:RequestInit={}):Promise<any>{const route=url.replace('/api/','');const r=await fetch(base+'/functions/v1/lindley-api/'+route,{...options,headers:{...options.headers,apikey:key,Authorization:'Bearer '+await token()}});const data=await r.json();if(!r.ok)throw new Error(data.error||'No se pudo completar la operación.');return data;}
