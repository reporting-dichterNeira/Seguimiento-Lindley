let reader:Promise<any>|null=null;
export function xlsx(){
 if((window as any).XLSX)return Promise.resolve((window as any).XLSX);
 if(!reader)reader=new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='./xlsx.full.min.js';script.onload=()=>resolve((window as any).XLSX);script.onerror=()=>{reader=null;reject(new Error('No se pudo cargar Excel. Intenta nuevamente.'))};document.head.appendChild(script)});
 return reader;
}
export async function exportExcel(rows:any[][],name:string){
 const X=await xlsx(),book=X.utils.book_new();
 const sheet=X.utils.aoa_to_sheet(rows);
 (rows[0]||[]).forEach((header:any,column:number)=>{if(String(header).includes('%'))for(let row=1;row<rows.length;row++){const cell=sheet[X.utils.encode_cell({r:row,c:column})];if(cell?.t==='n')cell.z='0.0%';}});
 sheet['!cols']=(rows[0]||[]).map(()=>({wch:24}));
 X.utils.book_append_sheet(book,sheet,'Datos');
 X.writeFile(book,name.replace(/[<>:"/\\|?*]/g,'-')+'.xlsx');
}
