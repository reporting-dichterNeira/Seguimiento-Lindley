# Seguimiento Lindley

Portal: https://reporting-dichterneira.github.io/Seguimiento-Lindley/

## Operación con MT

Dos fuentes operativas: export Databricks y Excel de universo con forecast integrado. En Administración selecciona el mes y carga el universo; se detecta la hoja por sus columnas, con preferencia por BD y encabezados dentro de las primeras 20 filas. El orden de las columnas no afecta la carga. Se reconocen Código / CODIGO, USUARIOS / MT, T/S / SELECCIÓN, TIPOLOGIA / Programa de Valor, Día de campo / DIA, RUTAS / RUT.COM y CDA2 / DES LOC_COM. Las columnas adicionales se ignoran. MT es obligatorio en todos los puntos; día de campo es obligatorio solo para titulares y opcional para suplentes. CODIGO cruza con ID_de_PDV. MT asigna los puntos, incluidas las visitas pendientes; en el plan integrado no se infieren responsables por ruta.

El forecast cuenta puntos titulares (SELECCION=T) por MT y DIA. Programa de Valor identifica Titanes. En automático, las fechas con 3 o más auditorías distintas de toda la ola avanzan el contador; las fechas con 1 o 2 se suman al día de campo anterior. Administración puede forzar la inclusión o exclusión de una fecha. Todos los estados identifican fechas; los estados efectivos suman al avance. El corte limita producción y metas a los días observados. Los días futuros mantienen el forecast sin inventar fechas calendario.

Carga un Excel de homologación con MT, Usuario y Nombre opcional. Usuario debe coincidir con nombre_usuario del export. Se rechaza repetir la misma pareja MT y Usuario. Se permiten MT compartidos y usuarios con varios MT. Las equivalencias se guardan por mes; el acceso MT usa la homologación más reciente. El servidor habilita las cuentas faltantes. Sin equivalencia, el MT queda pendiente. Cada auditor ve sus puntos asignados y sus visitas; el administrador ve el estudio completo.

## Databricks

Reporting Cluster: 1115-192254-jqnbpmi. Job automático export 448396700809372: 06:00, 12:00 y 17:00 America/Bogota. Consulta solo la Ola del mes actual y conserva otros meses. Actualizar histórico del export usa job 577854098883515 y consulta todo 2026/2027. Cada carga reemplaza la versión activa de la ola y conserva versiones privadas.

El job de forecast 873798021992995 queda PAUSADO y el servidor rechaza sus sincronizaciones. El forecast nuevo proviene del universo MT/DIA. Los meses con universo anterior conservan su información histórica.

## Supabase y código

GitHub contiene solo interfaz y fuente. Los datos, perfiles y homologaciones están en Supabase con autorización del servidor y bucket lindley-private protegido. Las tablas no tienen acceso directo desde el cliente. Aplica supabase/mt-plan.sql y despliega supabase/index.ts. El acceso MT conserva el límite de intentos; el servidor valida el rol y filtra por usuario del export. Las credenciales administrativas permanecen sin cambios.

fuente-lindley.zip contiene el proyecto editable. Instala npm ci y compila npm run build. Configura las claves públicas VITE_SUPABASE_ANON_KEY y VITE_SUPABASE_LOGIN_JWT. Nunca publiques claves de servidor, bases ni códigos de acceso. Databricks verifica la identidad temporal de la ejecución; el inicio manual utiliza una credencial leída únicamente en el servidor desde integrations/databricks.json.

Un usuario puede conservar varios MT. Un MT compartido admite varias filas de homologación y divide cuota, forecast y metas Titanes por partes iguales (50 % para dos personas), manteniendo el avance efectivo real por usuario del export. Al ingresar un MT compartido se selecciona el usuario del export. Las metas impares pueden expresarse con 0,5 para conservar el total exacto.

## Auditores por mes

En Administración, «Equivalencias y auditores del mes» permite añadir un auditor con Nombre, Usuario del export y uno o varios MT separados por comas. Las cuentas existentes se conservan; las nuevas se habilitan automáticamente. No es necesario volver a subir el Excel y pueden añadirse MT antes de actualizar el universo.

La casilla «Activo en el mes» controla la participación del auditor en ese periodo. El filtro muestra Todos, Activos, Inactivos y Retirados. «Eliminar del mes» requiere confirmar el retiro y conserva un registro recuperable; «Restaurar al mes» recupera sus equivalencias. Ninguna acción borra auditorías ni modifica otros meses. El estado se guarda en la versión de homologación del mes y queda en el historial de cargas. Subir otro Excel reemplaza estas equivalencias.

Solo los auditores activos participan en el reparto de las metas del MT. Si no queda ninguno activo, el MT queda sin homologar y su cuota se conserva en el total del estudio. Las efectivas históricas siguen atribuidas al usuario del export. Un auditor inactivo no puede usar ese MT para ingresar ni consultar el mes con una sesión previa. La lista manual comprueba la versión leída y pide actualizar si cambió antes de guardar.

## Universo completo

La cuota y el forecast cuentan solo titulares programados. Todos los suplentes están disponibles en Puntos de venta, incluso sin visita o sin día previsto. El filtro permite ver titulares o suplentes. SUPLENTES conserva S1, S2 y otros niveles cuando T/S indica S. Las efectivas de suplentes suman a producción sin aumentar las metas. Los estados históricos dentro del universo se ignoran: el estado actual siempre procede del export de Databricks. La pantalla Estados del export permite conciliar auditorías y puntos únicos; Última actualización corresponde a la última carga exitosa del export del mes, automática o manual.

## Visual de usuarios y estados

Las vistas de gestión muestran el usuario del export; cuando no hay equivalencia, muestran el MT. En Auditores y Administración se puede buscar por usuario o MT y filtrar MT compartidos o usuarios con varios MT. Las etiquetas muestran los códigos, y el detalle de un MT compartido permite consultar sus otros usuarios activos. Los filtros son de consulta y conservan las asignaciones. Estados del export se representa como barras con conteos, porcentaje y total de auditorías, para el mes y corte seleccionados.

En cada fila de Administración, «Editar MT» permite reemplazar todos los códigos de un usuario para el mes seleccionado. Se conservan el usuario, nombre, estado activo/retirado y otros meses. Se admiten varios MT y MT compartidos; el avance continúa por usuario del export. Guardar comprueba la versión de la lista y registra una nueva versión privada de homologación.

## Indicadores de efectivas

Efectivas cuenta puntos únicos del universo por ola y corte con Aprobada, En Proceso, Requiere Aprobación, Exenta por Validación Smart, Alerta o Cancelación Automática. Incidencia, Exenta y Cancelada se excluyen de efectivas en todos los indicadores, filtros y exportaciones. La última auditoría efectiva del punto determina el usuario y fecha de producción; varias auditorías no multiplican el avance. SubStatus identifica Exenta por Validación Smart y Cancelación Automática antes del estado principal. Otros subestados (Reconocimiento Manual, Mal Ejecutada, Incidente en PDV, etc.) conservan la categoría Estado. Los estados desconocidos y puntos sin visita no son efectivos.

Cuota, forecast y reparto de MT se conservan. Avance = efectivas / cuota; cumplimiento = efectivas / forecast; GAP mostrado = efectivas − forecast (negativo indica faltante); pendientes = máximo(0, cuota − efectivas). Titanes aplica las mismas reglas. Incidencia, Exenta y Cancelada se muestran por separado y no suman a efectivas. Los estados en revisión sí están incluidos y no deben sumarse de nuevo. La gráfica cuenta auditorías; los indicadores cuentan puntos. Databricks trae Estado y SubStatus en las sincronizaciones del mes actual y del histórico.

## Rutas, visitas CT y exportación

En Auditores, «Ver rutas» despliega las metas y efectivas de cada ruta/CDA del usuario. El reparto de MT compartidos se conserva y las rutas concilian con el resumen del auditor. El Excel del seguimiento incluye todos los desgloses por ruta, aunque estén contraídos. Los meses anteriores sin planificación por punto no inventan un forecast por ruta.

«Cerrado temporal» reúne puntos del universo que tuvieron Incidencia / Cerrado temporal en la ola y hasta el corte. Cuenta todas sus auditorías con ID_de_audito distinto, incluso con otro estado o varias en la misma fecha. Verde OK indica dos o más visitas; rojo Falta visita indica una. Hay filtros por seguimiento y búsqueda. Para auditores se muestran puntos de su gestión y el conteo agregado del punto, sin identidades ni registros de otros usuarios.

Todas las tablas tienen «Exportar Excel». Puntos de venta exporta todos los resultados filtrados con autorización del servidor, más allá de la página visible. Programa, selección y estados se combinan con AND; varios estados se incluyen con OR. Por ejemplo, Titanes + titulares + Sin visitar. Los filtros de consulta no cambian indicadores ni fuentes.

## Publicación en Vercel

Portal de producción: https://seguimiento-lindley.vercel.app
Equipo: reporting-dichterneira. Proyecto: seguimiento-lindley.

La versión 6f567fe se publicó con carga directa de index.html y xlsx.full.min.js, ambos idénticos al repositorio. Los cambios posteriores de interfaz se despliegan manualmente desde Vercel; este proyecto aún no tiene integración Git. Para preparar una nueva versión, compila, ejecuta package-pages.py y carga esos dos archivos juntos. Las actualizaciones de bases continúan en Supabase/Databricks y no requieren volver a publicar la interfaz.

La función lindley-api permite el origen exacto https://seguimiento-lindley.vercel.app, además del portal GitHub y los servidores locales existentes. La autorización por sesión, rol y auditor se conserva. Los dominios de preview no tienen acceso automático al backend. Se verificaron ingreso de auditor, acceso administrativo y exportación Excel desde el dominio de producción.


## Calendario de campo

Administración → Calendario de días de campo permite corregir cada mes. En automático, solo fechas con al menos tres ID_de_audito distintos de toda la ola cuentan como días de campo (todos los estados y usuarios). Las fechas con una o dos auditorías agrupan su productividad en el día de campo válido anterior. Si no existe un día anterior, conservan su fecha y no incrementan el calendario.

Día de campo fuerza la inclusión; Sumar al anterior fuerza la exclusión. Guardar recalcula la numeración, el forecast y las productividades diaria y semanal para todos los usuarios. Las fechas originales del export, las auditorías y el corte se conservan: nunca se anticipan visitas posteriores al corte. Los ajustes se guardan por mes como dataset privado calendar y sobreviven a la sincronización del export. Restablecer automático requiere Guardar. La activación utiliza una comparación de versión bajo bloqueo para evitar sobrescrituras concurrentes.

Para instalaciones existentes ejecutar supabase/migrations/20261013124844_field_calendar.sql y luego desplegar lindley-api. Para una instalación nueva ejecutar schema.sql, las demás migraciones necesarias y esta migración.


## Avance vs forecast lineal

La tarjeta administrativa compara efectivas acumuladas con la suma de las metas lineales hasta la fecha de corte elegida. El plan se guarda por mes como dataset privado linear-forecast; no se publica en el frontend ni se reparte automáticamente entre auditores. Cada meta conserva su fecha calendario, independientemente de las correcciones del calendario de campo. Días vacíos aportan cero. No se normaliza el total ni se limita el porcentaje a 100 %. Antes de la primera meta se muestra — para evitar división por cero; en meses sin plan se indica que no hay forecast lineal cargado. El forecast integrado del universo y sus GAP conservan su cálculo.

Ejecutar supabase/migrations/20261014125016_linear_forecast.sql después de las migraciones anteriores y desplegar supabase/index.ts. El servidor entrega el indicador únicamente a administradores; las metas usan el bucket privado y la activación versionada ya existentes.


## Semáforo de GAP en tarjetas

La tarjeta lineal muestra «efectivas / meta lineal» y GAP = efectivas − meta lineal. Los GAP se muestran en rojo cuando son negativos y en verde cuando son cero o positivos. Sin meta disponible se muestra — sin asignar un semáforo de cumplimiento. Los valores conservan su cálculo al corte. El criterio se aplica al resumen de forecast, al forecast lineal administrativo y a las tarjetas generales y de Titanes, tanto de administrador como de auditor.


## Forecast de campo por ola

Solo el administrador ve el forecast de campo. Se guarda por periodo como dataset privado field-forecast con CDA, fecha y meta diaria. Se suman filas repetidas por CDA y fecha; se excluyen los totales para evitar doble conteo y se conservan los decimales. La meta al corte suma fechas calendario hasta el corte, incluyendo jornadas con cero o visitas futuras aún no reportadas. Las efectivas conservan los seis estados vigentes y el corte real del export. El forecast de planeación del universo conserva su cálculo.

Las tarjetas de lineal y campo aparecen debajo de las cuatro tarjetas originales. La tarjeta de campo muestra porcentaje, efectivas, meta al corte y GAP = efectivas − meta de campo con el semáforo común. La tabla por CDA añade al final Meta al corte, Efectivas y GAP de campo, también incluidos en su exportación Excel. El total concilia con los CDA. Sin plan de campo para una ola no se muestran esta tarjeta ni sus columnas. Los auditores no reciben estas metas ni cambian sus visuales.

Para octubre de 2026 se usa la pestaña Hoja2 del archivo suministrado, con metas por CDA para 22 fechas. Los nombres se normalizan por mayúsculas, acentos y puntuación; el código AA relaciona Rutas del Sur Tacna con AA RUTAS DEL SUR S.A del portal. La base preparada conserva el nombre de origen. El archivo Excel original permanece intacto y sus hojas auxiliares no se importan.

Aplicar supabase/migrations/20261014133759_field_forecast.sql después de las migraciones anteriores y desplegar supabase/index.ts. Se conservan autorización, RLS y el bucket privado existentes.

## Validación por CDA

El botón «Ver estados de validación» en Seguimiento por CDA presenta el total de auditorías, sus estados y el porcentaje Requiere Aprobación / total; se puede exportar a Excel. La columna Navegador aparece inmediatamente después de CDA en el cuadro general. Los GAP mostrados en tablas, tarjetas y exportación usan efectivas menos forecast.
